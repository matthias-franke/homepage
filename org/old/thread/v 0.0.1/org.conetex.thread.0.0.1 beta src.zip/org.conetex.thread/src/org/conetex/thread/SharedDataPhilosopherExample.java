package org.conetex.thread;

import java.io.File;

import org.conetex.thread.Semaphor.SluiceJoined;
import org.conetex.thread.Semaphor.SluiceCluster;


/**
 * <p>Title: </p>
 * <p>Description: </p>
 * <p>Copyright: Copyright (c) 2001</p>
 * <p>Company: </p>
 * @author not attributable
 * @version 1.0
 */

public class SharedDataPhilosopherExample {
 
  public static java.io.PrintStream printer = System.out;
  //public static java.io.PrintStream printer = getFileWriter("C:\\philosopher.txt");

  public static java.io.PrintStream getFileWriter(String filename){
    
    try{
      return new java.io.PrintStream(new java.io.FileOutputStream(filename, false), true);
    }
    catch(java.io.FileNotFoundException e){
      //System.out.print(e.getMessage());
    }
    return null;
  }
  
  public static void main(String[] args){
    //Fool.main(null);
    //Philosopher.main(null);
    System.setOut(printer);
    NewPhilosopher.main(null);
    Thread t = new Thread(){
      public void run(){
        long time = System.currentTimeMillis();
        //int[] x = new int[NewPhilosopher.philosophers.length];
        int[] x = new int[2];
        for(int i = 0; i < x.length; i++){
          x[i] = NewPhilosopher.philosophers[i].forkOwnership;
        }
        boolean details = false;
        while(true){
          try{
            sleep(3000);
          }
          catch(InterruptedException e){
            // TODO Auto-generated catch block
            e.printStackTrace();
          }
          details = false;
          for(int i = 0; i < x.length; i++){
            if(x[i] == NewPhilosopher.philosophers[i].forkOwnership){
//System.out.println("DETTTTTTTTTTTTTT");              
              details = true;
            }
            x[i] = NewPhilosopher.philosophers[i].forkOwnership;
          }
          
          SharedDataPhilosopherExample.printer.print(
              "Status der Philosophen nach " +
              (System.currentTimeMillis() - time) + " ms :\r\n" +
              Philosopher.getPhilosopherString() + 
              NewPhilosopher.getPhilosopherString()
            );

          if(details){
          //  SharedDataPhilosopherExample.printer.print("Status der Gabeln :\r\n" +
          //      Fork.getForksString()
          //    );          
            SharedDataPhilosopherExample.printer.print(
                "Thread-Stand " +
                (System.currentTimeMillis() - time) + " ms :\r\n" +
                NewPhilosopher.getDetailsString()
              );
            
          }
          SharedDataPhilosopherExample.printer.println("--------------------------------------------------------------------------------------------------------------");
          
        }
      }
    };
    t.start();
    
  }

  private static class Fork extends Semaphor.SluiceCluster{

    public String owner;

    public static Fork[] forks;

    private String forkName;

    private Thread user;

    public Fork(String aForkName){
      this.forkName = aForkName;
    }

    protected void setUser(Thread aUser){
      if(this.user != null && aUser != null){
        //System.out.println("Okupation !!! " + this + " / " + this.user + " | " + aUser);
        throw new NullPointerException();
      }
      this.user = aUser;
    }

    protected static String getForksString(){
      String x = "";
      if(Fork.forks != null){
        for(int i = 0; i < Fork.forks.length; i++){
          x = x + "   " + Fork.forks[i] + "\r\n";
        }
      }
      return x;
    }

    public String toString(){
      return this.forkName + " - " + user;
    }

  }

  public static class NewPhilosopher extends Thread{
    int rank;
    public String details = "?";
    public int exams = 0;
    public static NewPhilosopher[] philosophers;
    
    public static void main(String[] args){
      Fork fa = new Fork("Gabel v. Foucault    u. Aristoteles");
      Fork ad = new Fork("Gabel v. Aristoteles u. Descartes  ");
      Fork dk = new Fork("Gabel v. Descartes   u. Kant       ");
      Fork km = new Fork("Gabel v. Kant        u. Marx       ");
      Fork mp = new Fork("Gabel v. Marx        u. Platon     ");
      Fork ph = new Fork("Gabel v. Platon      u. Habermas   ");
      Fork hf = new Fork("Gabel v. Habermas    u. Foucault   ");
      Fork[] x = {fa, ad, dk, km, mp, ph, hf};
      Fork.forks = x;

      NewPhilosopher a = new NewPhilosopher(fa, "Aristoteles", ad, 10, 10);
      NewPhilosopher d = new NewPhilosopher(ad, "Descartes  ", dk, 10, 20);
      NewPhilosopher k = new NewPhilosopher(dk, "Kant       ", km, 10, 30);
      NewPhilosopher m = new NewPhilosopher(km, "Marx       ", mp, 10, 40);
      NewPhilosopher p = new NewPhilosopher(mp, "Platon     ", ph, 10, 30);
      NewPhilosopher h = new NewPhilosopher(ph, "Habermas   ", hf, 10, 25);
      NewPhilosopher f = new NewPhilosopher(hf, "Foucault   ", fa, 10, 20);
/*
      NewPhilosopher a = new NewPhilosopher(fa, "Aristoteles", ad, 10, 10);
      NewPhilosopher d = new NewPhilosopher(ad, "Descartes  ", dk, 10, 10);
      NewPhilosopher k = new NewPhilosopher(dk, "Kant       ", km, 10, 10);
      NewPhilosopher m = new NewPhilosopher(km, "Marx       ", mp, 10, 10);
      NewPhilosopher p = new NewPhilosopher(mp, "Platon     ", ph, 10, 10);
      NewPhilosopher h = new NewPhilosopher(ph, "Habermas   ", hf, 10, 10);
      NewPhilosopher f = new NewPhilosopher(hf, "Foucault   ", fa, 10, 10);
*/      
      
      NewPhilosopher[] y = {a, d, k, m, p, h, f};
      NewPhilosopher.philosophers = y;
      
      a.start();
      d.start();
      k.start();
      m.start();
      p.start();
      h.start();
      f.start();
    }

    private String philosopherName;

    private int restTime;
    
    private int eatTime;

    private Fork leftFork;

    private Fork rightFork;
    
    private SluiceJoined forks;

    private int forkOwnership;
    
    public NewPhilosopher(Fork aLeftF, final String aPhilosopherName, Fork aRightF,
                       int aRestTime, int aEatTime){
      this.leftFork = aLeftF;
      this.rightFork = aRightF;
      SluiceCluster[] x = new SluiceCluster[2];
      x[0] = this.leftFork;
      x[1] = this.rightFork;
      this.forks = new SluiceJoined(x){
        public String toString(){
          return "ForksOf" + aPhilosopherName;// + " | user: " + this.user; 
        }
      };
      //this.forks.addRessource(this.leftFork);
      //this.forks.addRessource(this.rightFork);
      this.philosopherName = aPhilosopherName;
      this.restTime = aRestTime;
      this.eatTime = aEatTime;
    }

    public String toString(){
      return this.philosopherName;// + this.rank;
    }

    protected static String getPhilosopherString(){
      String x = "";
      if(NewPhilosopher.philosophers != null){
        for(int i = 0; i < NewPhilosopher.philosophers.length; i++){
          x = x + " " + NewPhilosopher.philosophers[i] + " " + NewPhilosopher.philosophers[i].status + ": " + NewPhilosopher.philosophers[i].exams + " - " + NewPhilosopher.philosophers[i].forkOwnership + "\r\n";
        }
      }
      return x;
    }

    protected static String getDetailsString(){
      String x = "";
      if(NewPhilosopher.philosophers != null){
        for(int i = 0; i < NewPhilosopher.philosophers.length; i++){
          x = x + " " + NewPhilosopher.philosophers[i] + " at " + NewPhilosopher.philosophers[i].details + "\r\n";
//          x = x + "   " + NewPhilosopher.philosophers[i].forks + " | locks: " + NewPhilosopher.philosophers[i].forks.lock + " | owner: " + NewPhilosopher.philosophers[i].forks.owner  + " | lockOwner: " + NewPhilosopher.philosophers[i].forks.lockOwner + "\r\n";
          x = x + "     " + NewPhilosopher.philosophers[i].leftFork + " | owner: " + NewPhilosopher.philosophers[i].leftFork.owner + "\r\n";
          x = x + "     " + NewPhilosopher.philosophers[i].rightFork + " | owner: " + NewPhilosopher.philosophers[i].rightFork.owner + "\r\n";
        }
      }
      return x;
    }
    
    
    public void run(){
      while(true){
        // nachdenken
        status = " sleeping";
        this.rest();
        ////System.out.println(".");
        // gabeln nehmen
/*        
SharedDataPhilosopherExample.printer.print("Gabeln vor dem Aufnehmen durch " +
                                             this + ":\r\n" +
                                             Fork.getForksString());
*/                          
        status = " hungry  ";
        this.forkesTake();
        // essen
/*        
SharedDataPhilosopherExample.printer.print("Gabeln w�hrend " +
                                             this + " isst:\r\n" +
                                             Fork.getForksString());
*/                                     
        status = " eating  ";
        this.eat();
////System.out.println("putttt ");        
        // gabeln ablegen
        status = " sleepy  ";
        this.forkesPut();
      }
    }

    private void forkesTake(){
      this.forks.enter();
      //Semaphor.enter(x);        // ok
      //Semaphor.enterStupid(x);  // ok
      //Semaphor.enterSwap(x);    // ok
////System.out.println(x + " entered setUser for " + leftFork + " and " + rigthFork);
      leftFork.setUser(this);
      rightFork.setUser(this);
      this.forkOwnership++;
    }

    private void forkesPut(){
      leftFork.setUser(null);
      rightFork.setUser(null);
      this.forks.leave();
    }

    String status = null;
    
    private void rest(){
      try{
        Double d = new Double( this.restTime * Math.random() );
        Thread.sleep( d.longValue() + 1);
      }
      catch(InterruptedException e){
        //nichts
      }
    }

    private void eat(){
      try{
        Double d = new Double( this.eatTime * Math.random() );
        ////System.out.println(d.longValue() + " | " +d);
        Thread.sleep( d.longValue() + 1);
      }
      catch(InterruptedException e){
        //nichts
      }
    }    
    
  }

  private static class Philosopher extends Thread{

    public static Philosopher[] philosophers;
    
    public static void main(String[] args){
      Fork ha = new Fork("Gabel von Habermas und Aristoteles");
      Fork ad = new Fork("Gabel von Aristoteles und Descartes");
      Fork dk = new Fork("Gabel von Descartes und Kant");
      Fork km = new Fork("Gabel von Kant und Marx");
      Fork mp = new Fork("Gabel von Marx und Platon");
      Fork ph = new Fork("Gabel von Platon und Habermas");
      Fork[] x = {ha, ad, dk, km, mp, ph};
      Fork.forks = x;

      Philosopher p = new Philosopher(mp, "Platon", ph, 10, 100);
      Philosopher h = new Philosopher(ph, "habermas", ha, 1200, 100);
      Philosopher a = new Philosopher(ha, "Aristoteles", ad, 300, 100);
      Philosopher d = new Philosopher(ad, "Descartes", dk, 600, 100);
      Philosopher k = new Philosopher(dk, "Kant", km, 900, 100);
      Philosopher m = new Philosopher(km, "Marx", mp, 1200, 100);
 
      Philosopher[] y = {p, h, a, d, k, m};
      Philosopher.philosophers = y;
      
      p.start();
      h.start();
      a.start();
      d.start();
      k.start();
      m.start();
    }

    private String philosopherName;

    private int restTime;
    
    private int eatTime;

    private Fork leftFork;

    private Fork rigthFork;

    private int forkOwnership;
    
    public Philosopher(Fork aLeftF, String aPhilosopherName, Fork aRightF,
                       int aRestTime, int aEatTime){
      this.leftFork = aLeftF;
      this.rigthFork = aRightF;
      this.philosopherName = aPhilosopherName;
      this.restTime = aRestTime;
      this.eatTime = aEatTime;
    }

    public String toString(){
      return this.philosopherName + this.status;
    }

    protected static String getPhilosopherString(){
      String x = "";
      if(Philosopher.philosophers != null){
        for(int i = 0; i < Philosopher.philosophers.length; i++){
          x = x + "   " + Philosopher.philosophers[i] + ": " + Philosopher.philosophers[i].forkOwnership + "\r\n";
        }
      }
      return x;
    }
    
    public void run(){
      while(true){
        // nachdenken
        status = " waeting";
        this.rest();
        // gabeln nehmen
/*        
SharedDataPhilosopherExample.printer.print("Gabeln vor dem Aufnehmen durch " +
                                             this + ":\r\n" +
                                             Fork.getForksString());
*/                                             
        this.forkesTake();
        // essen
/*        
SharedDataPhilosopherExample.printer.print("Gabeln w�hrend " +
                                             this + " isst:\r\n" +
                                             Fork.getForksString());
*/                                     
        status = " eating";
        this.eat();
        // gabeln ablegen
        this.forkesPut();
      }
    }

    private void forkesTake(){
      Fork[] x = {leftFork, rigthFork};
      //Semaphor.enter(x);        // ok
      //Semaphor.enterStupid(x);  // ok
      //Semaphor.enterSwap(x);    // ok
////System.out.println(x + " entered setUser for " + leftFork + " and " + rigthFork);
      leftFork.setUser(this);
      rigthFork.setUser(this);
      this.forkOwnership++;
    }

    private void forkesPut(){
      leftFork.setUser(null);
      rigthFork.setUser(null);
      Fork[] x = {leftFork, rigthFork};
      Semaphor.leave(x);
    }

    String status = null;
    
    private void rest(){
      try{
        Thread.sleep(this.restTime);
      }
      catch(InterruptedException e){
        //nichts
      }
    }

    private void eat(){
      try{
        Thread.sleep(this.eatTime);
      }
      catch(InterruptedException e){
        //nichts
      }
    }    
    
  }

  private static class Fool extends Thread{

    public static void main(String[] args){
      Fork pa = new Fork("Gabel von Platon und Aristoteles");
      Fork ad = new Fork("Gabel von Aristoteles und Descartes");
      Fork dk = new Fork("Gabel von Descartes und Kant");
      Fork km = new Fork("Gabel von Kant und Marx");
      Fork mp = new Fork("Gabel von Marx und Platon");

      Fork[] x = {pa, ad, dk, km, mp};
      Fork.forks = x;

      Fool p = new Fool(mp, "Platon", pa, 50);
      Fool a = new Fool(pa, "Aristoteles", ad, 50);
      Fool d = new Fool(ad, "Descartes", dk, 50);
      Fool k = new Fool(dk, "Kant", km, 50);
      Fool m = new Fool(km, "Marx", mp, 50);

      p.start();
      a.start();
      d.start();
      k.start();
      m.start();
    }

    private String philosopherName;

    private int restTime;

    private Fork leftFork;

    private Fork rigthFork;

    public Fool(Fork aLeftF, String aPhilosopherName, Fork aRightF,
                       int aRestTime){
      this.leftFork = aLeftF;
      this.rigthFork = aRightF;
      this.philosopherName = aPhilosopherName;
      this.restTime = aRestTime;
    }

    public String toString(){
      return this.philosopherName;
    }

    public void run(){
      while(true){
        // nachdenken
        this.rest();
        // gabeln nehmen
SharedDataPhilosopherExample.printer.println("Gabeln vor dem Aufnehmen durch " +
                                             this + ":\n\r"  +
                                             Fork.getForksString());
        this.forkesTake();
        // essen
SharedDataPhilosopherExample.printer.println("Gabeln w�hrend " +
                                             this + " isst:\n\r" +
                                             Fork.getForksString());
        this.rest();
        // gabeln ablegen
        this.forkesPut();
      }
    }

    private void forkesTake(){
      leftFork.enter();
      leftFork.setUser(this);
      rigthFork.enter();
      rigthFork.setUser(this);
    }

    private void forkesPut(){
      leftFork.leave();
      leftFork.setUser(null);
      rigthFork.leave();
      rigthFork.setUser(null);
    }

    private void rest(){
      try{
        Thread.sleep(this.restTime);
      }
      catch(InterruptedException e){
        //nichts
      }
    }

  }

}