/*
  <h1 id="org.conetex.thread" name="org.conetex.thread">
   org.conetex.thread
  </h1>
  <p>
   org.conetex.thread ist ein freies Java-Framework zur Verwaltung von Threads zur Verf�gung.
   Bereits mit Version 1 des Framesworks bietet Java-Entwickler eine elegante L�sung g�ngiger
   Synchronisationsprobleme. So l��t sich auf Basis des Frameworks eine einfache Highlevel-Implementierung
   des bekannten <a href="#Philosophenproblem">Philosophenproblems</a> erstellen:
  </p>
  <h2 id="Inhalt" name="Inhalt">
   Inhalt
  </h2>
  <ul>
   <li>
    <a href="#org.conetex.thread" name="org.conetex.thread">
     org.conetex.thread
    </a>
    <ul>
     <li>
      <a href="#Inhalt" name="Inhalt">
       Inhalt
      </a>
     </li>
     <li>
      <a href="#KONZEPTE" name="KONZEPTE">
       Konzepte
      </a>
      <ul>
       <li>
        <a href="#SEMAPHOR" name="SEMAPHOR">
         Semaphor
        </a>
       </li>
       <li>
        <a href="#SYNCHRONIZED MONITOR IN JAVA" name="SYNCHRONIZED MONITOR IN JAVA">
         Synchronized Monitor in Java
        </a>
       </li>
      </ul>
     </li>
     <li>
      <a href="#RESSOURCE SINGLE" name="RESSOURCE SINGLE">
       Sluice -
       <br />
       Implementierung des Semaphor-Konzepts durch Monitore
      </a>
      <ul>
       <li>
        <a href="#ZUGRIFFSERLAUBNIS" name="ZUGRIFFSERLAUBNIS">
         Zugriffserlaubnis
        </a>
       </li>
      </ul>
     </li>
     <li>
      <a href="#RESSOURCE DEPENDING" name="RESSOURCE DEPENDING">
        SluiceCluster, SluiceJoined -
       <br />
        Implementierung von Abh�ngigkeiten zwischen Semaphoren
      </a>
      <ul>
       <li>
        <a href="#Philosophenproblem" name="Philosophenproblem">
         Das Philosophenproblem
        </a>
       </li>
      </ul>
     </li>
     <li>
      <a href="#Implementierung" name="Implementierung">
       Implementierung
      </a>
     </li>
    </ul>
   </li>
  </ul>
  <h2 id="KONZEPTE" name="KONZEPTE">
   Konzepte<!--KONZEPTE-->
  </h2>
  <h3 id="SEMAPHOR" name="SEMAPHOR">
   Semaphor<!--SEMAPHOR-->
  </h3>
  <p>
   Das Semaphor ist ein Konstrukt zur Kontrolle des Zugriffs auf
   gemeinsame Ressourcen durch mehrere Prozesse. Es wurde urspr�nglich
   von Dijkstra vorgeschlagen und basiert auf einer ganzzahligen
   Variablen als Flag zur Darstellung der Zugriffserlaubnis und einer
   Warteschlange von Prozessen, denen der Zugriff zun�chst verweigert
   wurde. Der Semaphor kennt zwei Operationen:
  </p>
  <ul>
   <li>
    <h4>
     ENTER
    </h4>
    <p>
     Die Operation "down" (in dieser Implementierung "enter") realisiert die
     Warteoperation beim Betreten eines kritischen Bereichs. Gem�� des Status
     der Zugriffserlaubnis wird das Betreten des kritischen Bereichs erlaubt oder
     der Prozess unterbrochen und in der Warteschlange abgelegt. Intern wird die
     Variable heruntergez�hlt. Als Reminiszenz an den holl�ndischen Erfinder
     Dijkstra wird diese Operation oft auch "p" f�r "passeer" genannt.
    </p>
   </li>
   <li>
    <h4>
     LEAVE
    </h4>
    <p>
     Die Operation "up" (in dieser Implementierung "leave") realisiert eine
     Signaloperation beim Verlassen des kritischen Bereichs. Intern wird die
     Variable heraufgez�hlt. Ist die Warteschlange von Prozessen nicht leer, so
     wird einer der wartenden Prozesse aktiviert. Als Name von "up"
     wird oft auch "v" f�r holl�ndisch "verlaat" gew�hlt.
    </p>
   </li>
  </ul>
  <h3 id="SYNCHRONIZED MONITOR IN JAVA" name="SYNCHRONIZED MONITOR IN JAVA">
   Synchronized Monitor in Java<!--SYNCHRONIZED MONITOR IN JAVA-->
  </h3>
  <p>
   Ein Monitor ist die Kapselung eines kritischen Bereichs
   (also eines Programmteils, der nur von jeweils einem Prozess zur Zeit
   durchlaufen werden darf) mit Hilfe einer automatisch verwalteten Sperre.
   Diese Sperre wird beim Betreten des Monitors gesetzt und beim Verlassen
   wieder zur�ckgenommen. Ist sie beim Eintritt in den Monitor bereits von
   einem anderen Prozess gesetzt, so mu� der aktuelle Prozess warten, bis
   der Konkurrent die Sperre freigegeben und den Monitor verlassen hat.
   Das Monitor-Konzept lie�e sich unter Verwendung eines Semaphor
   implementieren, dessen Operation "down" beim Betreten des zu gesch�tzten
   Programmteils aufgerufen wird und dessen Operation "up" beim Verlassen des
   gesch�tzten Programmteils aufgerufen wird.
  </p>
  <p>
   Die 'synchronized'-Deklaration in Java realisiert das Monitor-Konzept.
   Durch synchronized kann entweder eine komplette Methode oder ein Block
   innerhalb einer Methode gesch�tzt werden. Der Eintritt in den so
   deklarierten Monitor wird durch das Setzen einer Sperre auf einer
   Objektvariablen erreicht. Bezieht sich synchronized auf eine komplette
   Methode, wird als Sperre der this-Pointer verwendet, andernfalls ist
   eine Objektvariable explizit anzugeben.
  </p>
  <h2 id="RESSOURCE SINGLE" name="RESSOURCE SINGLE">
   RESSOURCE SINGLE -
   <br />
   Implementierung des Semaphor-Konzepts durch Monitore<!--IMPLEMENTIERUNG DES SEMAPHOR-KONZEPTS DURCH MONITORE-->
  </h2>
  <h3 id="ZUGRIFFSERLAUBNIS" name="ZUGRIFFSERLAUBNIS">
   Zugriffserlaubnis<!--ZUGRIFFSERLAUBNIS-->
  </h3>
  <p>
   Das Interface Semaphore definiert einen gesch�tzten Bereich, der nur von
   einem Thread gleichzeitig betreten werden kann. Die Klasse Sluice
   implementiert Semaphore gem�� des Semaphor-Konzepts. Die Methode enter()
   implementiert das Betreten des kritischen Bereichs analog zur Semaphor-
   Operation 'down'. Die Methode leave() realisiert das Verlassen des kritischen
   Bereichs analog zur Semaphor- Operation 'up'. Sluice verwendet eine
   Variable 'locked' vom Typ 'boolean' als Flag zur Darstellung der
   Zugriffserlaubnis. 'locked' wird innerhalb von enter() auf true gesetzt,
   innerhalb von leave() wird 'locked' auf false gesetzt. Dadurch, dass enter()
   und leave() als synchronized gekennzeichnet sind, ist der Zugriff auf
   'locked' gesch�tzt - Java-Threads, die auf einen per 'synchronized' gesetzten
   Monitor treffen, warten bis die Sperre aufgehoben wird, also der Konkurrent
   den Monitor verlassen hat.
  </p>
  <p>
   Das Semaphor verf�gt �ber eine Warteschlange von Prozessen, denen der Zugriff
   zun�chst verweigert wurde, da der gesch�tzte Bereich bereits von einem
   Prozess betreten wurde. Die Klasse Sluice verwendet die Java interne
   Warteliste f�r Threads, die in 'Object' indirekt durch die Benutzung von
   'wait()' zur Verf�gung steht: Versucht ein Thread B Zurgriff auf den
   gesch�tzten Bereich zu erhalten, so ruft er enter() auf. Ist der gesch�tzte
   Bereich bereits im Zugriff eines Threads A, so wird der Thread B durch den
   Aufruf von wait() unterbrochen. Dadurch gelangt Thread B in die von Java
   pro Object verwaltete Liste wartender Threads. Verl��t nun Thread A durch den
   Aufruf der Methode 'leave' den gesch�tzten Bereich, so wird mit 'notify()'
   ein wartender Thread aus der Warteliste reaktiviert. Der reaktivierte
   Thread B setzt also die Verarbeitung in enter() fort und erh�lt dadurch
   den Zugriff auf den gesch�tzten Bereich, auf den er gewartet hatte.
  </p>
  <h2 id="RESSOURCE DEPENDING" name="RESSOURCE DEPENDING">
    RESSOURCE DEPENDING, RESSOURCE MANAGED -
   <br />
    Implementierung von Abh�ngigkeiten zwischen Semaphoren<!--IMPLEMENTIERUNG VON ABHAENGIGKEITEN ZWISCHEN SEMAPHOREN-->
  </h2>
  <p>
   Die Kontrolle des Zugriffs auf gemeinsame genutzte Ressourcen ist komplexer,
   wenn zwischen den Ressourcen Abh�ngigkeiten bestehen. Die Schwierigkeit
   der Synchronisation abh�ngiger Zugriffe wird oft anhand des Philosophenproblems verdeutlicht:
  </p>
  <h3 id="Philosophenproblem" name="Philosophenproblem">
   Das Philosophenproblem
  </h3>
  <p>
   F�nf Philosophen sitzen an einem runden Tisch.
  </p>
  <p>
   Zwischen zwei Philosophen liegt jeweils eine Gabel auf dem Tisch. Der
   Lebenszyklus eines jeden Philosophen besteht aus den Operationen "Essen"
   und "Schlafen" und l�uft jeweils in einem eigenen Prozess / Thread ab. Die
   L�nge der Essensphase wird durch Zufall bestimmt. Zum Essen ben�tigt der
   Philosoph die linke Gabel, die zwischen ihm und seinem linken Nachbarn
   liegt, und die rechte Gabel, die zwischen ihm und seinem rechten Nachbarn
   liegt. Der Philosoph kann auf die Gabel nur dann zugreifen, wenn diese
   gerade nicht von seinem Nachbarn verwendet wird.
  </p>
  <p>
   Durch Verwendung von f�nf einfachen Semaphoren (Sluice), die jeweils
   den Zugriff auf eine Gabel synchronisiert, ist sichergestellt, dass eine
   Gabel zur gleichen Zeit nur von einem Philosophen verwendet wird. Die Klasse
   Gabel wird dazu von Sluice abgeleitet und implementiert damit das
   Interface Semaphore.
  </p>
  <p>
   Aber sobald der Philosoph eine seiner Gabeln festh�lt, wartet er darauf,
   dass er auch Zugriff auf die zweite Gabel erh�lt, die von seinem Nachbar
   festgehalten wird. Fr�her oder sp�ter befinden sich alle Philosophen in
   diesem Wartezustand: Jeder der f�nf Philosophen h�lt eine der f�nf Gabeln
   fest, dadurch erh�lt keiner der wartenden Philosophen den Zugriff auf eine
   zweite Gabel - die Philosophen verhungern.
  </p>
  <p>
   Das gegenseitige Blockieren k�nnen die Philosophen dadurch vermeiden, dass
   sie ihre Gabel wieder loslassen und freigeben, wenn sie keinen Zugriff auf
   die zweite Gabel erhalten. Es gibt zwei M�glichkeiten bei der Implementierung
   Deadlocks auszuschlie�en:
  </p>
  <ul>
   <li>
    <p>
     Der Zugriff auf die beiden Gabeln des Philosophen wird in einer einzelnen
     Operation enter(Semaphore[]) zusammengefasst. Der Philosoph erh�lt damit
     Zugriff auf beide Gabeln oder keine der Gabeln. Das Festhalten nur einer der
     Gabeln ist nicht mehr m�glich.
    </p>
    <p>
     Da die Klasse Gabel von Sluice abgeleitet ist, k�nnen die Objekte
     "rechte Gabel" und "linke Gabel" in einem Array einfach an die statische
     Methode enter(Semaphore[]) �bergeben werden. Diese Methode versucht der Reihe
     nach Zugriff auf jedes der Semaphore-Objekt im Array zu erhalten. Ist eines
     der Objecte im Array durch einen anderen Thread bereits gesperrt worden, gibt
     enter(Semaphore[]) diejenigen Objecte, auf die es Zugriff erhalten konnte,
     wieder frei. Daraufhin wartet enter(Semaphore[]) bis die von dem anderen
     Thread gesperrte Semaphore wieder frei wird, und versucht erneut der Reihe
     nach den Zugriff auf alle Semaphore-Objekte im Array zu erhalten.
     F�r das Philosophenproblem hei�t das, dass der Philosoph die Gabel, auf die
     er bereits Zugriff hat, zur�cklegt, wenn seine zweite Gabel von seinem
     Nachbarn verwendet wird. Er wartet solange, bis er nach Ende der Essensphase
     des Nachbarn auf die zweite Gabel zugreifen kann, und versucht dann erneut,
     auch auf beide Gabeln zuzugreifen.
    </p>
   </li>
   <li>
    <p>
     Der Zugriff auf die beiden Gabeln des Philosophen wird als einzelner
     Zugriff auf ein gemeinsames Objekt (SluiceJoined) implementiert, das die
     beiden Gablen verwaltet. F�r jeden Philosophen wird ein SluiceJoined-
     Object eingef�hrt. Die beiden Gabeln eines Philosophen werden bei ihrem
     gemeinsamen SluiceJoined-Object registriert. Dazu wird die Gabel-Klasse
     von SluiceCluster abgeleitet, um das Gabel-Object an die Methode
     addDependingRessource(SluiceCluster) des SluiceJoined-Objects zu
     �bergeben. Jede Gabel ist damit erstens beim SluiceJoined-Object des
     Philosophen registriert, der sie mit der linken Hand aufnimmt, und zweitens
     bei dem SluiceJoined-Object von dessen Nachbarn registriert, der die
     Gabel mit der rechten Hand aufnimmt.
    </p>
    <p>
     Wird auf eine Gabel zugegriffen, so informiert die Methode enter() alle
     SluiceJoined-Objecte, bei denen die Gabel registriert ist. Dadurch kann
     ein Z�hler im SluiceJoined-Object Auskunft dar�ber geben, dass sich eine
     der registrierten SluiceCluster-Objecte also Gabel-Objecte im Zugriff
     eines anderen Prozesses befindet. Versucht also ein Philosoph seine Gabeln
     aufzunehmen, indem er die Methode enter() des SluiceJoined-Objects
     aufruft, wird der Philosoph in den Wartezustand versetzt, ohne dass es n�tig
     ist, den Zugriff auf die Gabeln der Reihe nach auszuprobieren. Die
     Information, dass eine der ben�tigten Gabeln durch einen anderen Prozess
     blockiert ist, liegt ja bereits vor.
    </p>
    <p>
     Wird die Gabel frei, so informiert die Methode leave() alle SluiceJoined-
     Objecte, bei denen die Gabel registriert ist. Der Z�hler im SluiceJoined-
     Object wird heruntergesetzt. Steht der Z�hler damit wieder auf null, so
     bedeutet dies, dass keine der beim SluiceJoined-Object registrierten
     Gabeln in Benutzung ist. Der Philosoph, den das SluiceJoined-Object zuvor
     in den Wartezustand versetzte, wird in diesem Fall wieder aufgeweckt, denn
     nun lohnt sein Versuch, auf die frei gewordenen Gabeln zugreifen. Der Zugriff
     auf die einzelnen Gabel, der - wie oben beschrieben - als Aufruf der Methode
     enter() eines SluiceCluster-Objects implementiert ist, inkrementiert
     nun wieder die Z�hler der RessoureManaged-Objecte, bei denen die Gabel
     registriert ist. ResourceManaged kann auf diese Weise zentral den Zugriff
     auf eine Menge von Ressourcen regeln, ohne dass die Zugriffe auf die Elemente
     der Menge unn�tig oft einzeln durchprobiert werden m�ssen. Daher lohnt eine
     Implementierung mit SluiceJoined vorallem dann, wenn es gilt, eine
     gr��ere Menge von Ressourcen zu verwalten.
    </p>
   </li>
  </ul>
  <h2 id="Implementierung" name="Implementierung">
   Implementierung
  </h2>
*/
package org.conetex.thread;

import java.util.HashSet;
import java.util.Iterator;

/* Version 0.0.1 */
public class Semaphor{
  
  public static interface Semaphore{ // Ressource

    public boolean isLocked();

    public boolean tryEnter();

    public void enter();

    public void leave();

  }

  public static class Sluice implements Semaphore{ // RessourceSingle

    /*
     * Flag zur Darstellung der Zugriffserlaubnis.
     * Wenn 'locked == true' ist der Zugriff verboten.
     * Wenn 'locked == false' ist der Zugriff erlaubt.
     */
    private boolean locked;

    public Sluice(){
      this.locked = false;
    }

    public final synchronized boolean tryEnter(){
      if(this.locked){
        return false;
      }
      this.locked = true;
      return true;
    }

    /*
     *   Der aktuell aufrufende Thread betritt hier den durch den Semaphore
     *   gesch�tzten Bereich.
     */
    public final synchronized void enter(){
      ////System.out.println("enter   ");
      while(this.locked){
        //// 'locked == true' zeigt an, dass die Semaphore-Sperre bereits gesetzt
        //// wurde. Der aktuell aufrufende Thread wartet daher und verl�sst
        //// nicht diese Methode, um die Verarbeitung fortzusetzen. Erst wenn der
        //// Thread, der die Semaphore-Sperre setzte, den gesch�tzten Bereich
        //// mit dem Aufruf von 'leave()' verl�sst, wird einer der wartenden
        //// Threads wieder aktiviert.
        // Im Detail:
        // Der aktuell aufrufende Thread wird hier durch den Aufruf von wait(),
        // in die Warteliste des Semaphore-Objects aufgenommen. Dadurch wird er
        // unterbrochen und im Scheduler als wartend markiert. Erst der Aufruf
        // von 'notify()' in 'leave()' entfernt einen beliebigen Prozess aus der
        // Warteliste des Semaphore-Objekts und f�hrt ihn normalem Scheduling zu.
        ////System.out.println("Boom " + this.toString());
        try{
          this.wait();
        }
        catch(InterruptedException e){
          /** @todo wie ist diese Exception hier zu behandeln? */
        }
      }
      ////////////////////////////////////////////////////////////////////////////
      // Der folgende Abschnitt kann unter zweierlei
      // Umst�nden betreten werden:
      // A. Der vorstehende Block wurde durch den aktuellen Thread betreten,
      //    da 'locked == true'. Wegen des Aufrufs von 'wait()' wartete dieser
      //    Thread zun�chst, ist nun aber durch den Aufruf von 'notify()' wieder
      //    aktiviert worden, so dass er obigen Block verlie� und den folgenden
      //    Abschnitt betritt. Kann obiger Block verlassen werden, wenn
      //    'locked == true' (dies ist der Fall bei einem 'if'-Block, der ja
      //    'locked' nur beim Betreten, nicht aber beim Verlassen ausgewertet
      //    wird), so k�nnte betreffender Thread den gesch�tzten Bereich
      //    betreten, obwohl dieser durch 'locked' noch immer als gesperrt
      //    gekennzeichnet ist. Dies l��t sich durch die Verwendung eines
      //    'while'-Blocks statt eines 'if'-Blocks einfach verhindern.
      //    Im Detail:
      //    Wird ein 'if'-Block verwendet, so kann ein Thread, der im Wettbewerb
      //    um das Betreten der 'synchronized'-Bl�cke zun�chst gegen den
      //    aufgeweckten Thread gewonnen hatte und somit den folgenden Abschnitt
      //    betritt, 'locked' auf 'true' setzen. Verl��t dieser Gewinner-Thread
      //    daraufhin den 'synchronized'-Block, um Bearbeitungen nach 'enter()'
      //    durchzuf�hren, so erh�lt nun der geweckte Thread den Monitor 'this'
      //    und f�hrt die Bearbeitung von 'enter()' fort, obwohl der Gewinner-
      //    Thread die zu sch�tztende Sluice noch nicht durch den Aufruf von
      //    'leave()' freigegeben hatte.
      // B. Der vorstehende Block wurde nicht betreten, da 'locked == false'.
      //    'locked == false' zeigt an, dass die Semaphore-Sperre noch nicht
      //    gesetzt wurde. Der aktuell aufrufende Thread wartet daher nicht und
      //    verl��t diese Methode, um die Verarbeitung fortzusetzen.
      ////////////////////////////////////////////////////////////////////////////
      // Gilt nun, dass
      // 1. nur ein Thread den folgenden Abschnitt betritt,
      // 2. die Semaphore-Sperre legal aufghoben ist, also 'locked' legal auf
      //    'false' gesetzt wurde,
      // so sichert die folgende Anweisung die Konsistenz der Semaphore-Sperre:
      //// Um Threads warten zu lassen, die im Folgendem diese Methode betreten
      //// bevor der aktuelle aufrufende Thread den durch den Semaphore den
      //// gesch�tzten Bereich mit dem Aufruf von 'leave()' verl��t, wird die
      //// Semaphore-Sperre nun gesetzt. Dazu wird 'locked' auf 'true' gesetzt.
      this.locked = true;
    }

    /*
     *   Der aktuell aufrufende Thread verl��t hier
     *   den durch den Semaphore gesch�tzten Bereich.
     */
    public final synchronized void leave(){
      //// Um Threads im Folgendem zu erlauben, die
      //// Verarbeitung nach dem Betreten von 'enter()'
      //// fortzusetzen, wird die Semaphore-Sperre
      //// entfernt, das hei�t 'locked' wird auf
      //// 'false' gesetzt.
      this.locked = false;
      //// Da die Sperre nun entfernt ist, kann jetzt
      //// eine eventuell wartender Thread aktiviert werden.
      // Da diese Methode als 'synchronized' deklariert ist,
      // bleibt sichergestellt, dass kein weiterer Thread
      // Code dieses Semaphore-Objects ausf�hren kann und
      // so wegen der oben gerade aufgehobenen Sperre
      // gleichzeitig mit dem eventuell gleich per 'notify()'
      // wieder aktivierten Thread den zu sch�tzenden
      // Bereich betritt.
      this.notify();
    }

    public final synchronized boolean isLocked(){
      return this.locked;
    }

  }

/*
Class SluiceJoined
Managed ressource interact with there depending ressource in the following 
monitor-synchronized way:
    _________________       _________________       __________________
=  |   Monitor       |     | Monitor         |     | Monitor          |
=  |   SluiceJoined  |     | Lock            |     | SluiceCluster    |
=  |    _____________|_____|_      ________  |     |                  |
   |   | enter       |     | |...>|isLocked| |     |                  |
t  |   |             |     | |    |________| |     |      __________  |
i  |   |             |     | |..........................>| tryEnter | |
m  |   |             |    _|_|..........................>|          | |
e  |   |             |   | |                 |  ___|_____|          | |
   |   |             |   | |    _______     _|_|  _|________________| |
=  |   |             |   | |   |addLock|<..| |   | |                  |
=  |   |             |   |_|_  |_______|   |_|___| |                  |
=  |   |             |     | |....................................... |
=  |   |_____________|_ w _|_|..................................... : |
=  |      ________   | |a| |                 |     |              : : |
=  | ...>| notify |  | |i| |                 |     |              : : |
=  | :   |________|...>|t| |                 |     |              : : |
=  | :  _____________|_|e|_|_      ________  |     |              : : |
=  | : |             |     | |...>| addLock| |     |              : : |
=  | : |_____________|_____|_|    |________| |     |              : : |
V  |_:_______________|     |_________________|     |______________:_:_|
    _:_______________       _________________       ______________:_:_
=  | : Monitor       |     | Monitor         |     | Monitor      : : |
=  | : Res.Managed   |     | Lock            |     | Res.Depending: : |
=  | :  _____________|_____|_                |     |     _____    : : |
   | : | leave       |     | |.........................>|leave|<..: : |
t  | : |         ____|_____|_|.........................>|     |<....: |
i  | : |        |    |     |                 |  ___|____|     |       |
m  | : |        |    |  ___|__________      _|_|  _|__________|       |
e  | : |        |   _|_|   |removeLock|<...| |   | |                  |
   | : |        |  | |    _|__________|    |_|___| |                  |
=  | :.............|_|___| |                 |     |                  |
=  | : |        |____|_____|_      ________  |     |                  |
=  | : |             |     | |...>| unlock | |     |                  |
=  | :.|_____________|_____|_|    |________| |     |                  |
V  |_________________|     |_________________|     |__________________|

*/  
  public static class SluiceJoined implements Semaphore{ // RessourceManaged

    private Lock lock;
    
    private SluiceCluster[] ressource;
    
    private final HashSet ressourceHash;

    public SluiceJoined(){
      this.lock = new Lock();
      this.ressourceHash = new HashSet();
    }
    
    public SluiceJoined(SluiceCluster[] managed){
      this.lock = new Lock();
      this.ressourceHash = new HashSet();
      for(int i = 0; i < managed.length; i++){
        this.addDependingRessource(managed[i]);
      }
    }

    public final boolean isLocked(){
      synchronized(this.lock){
        if(this.lock.count > 0){
          return true;
        }
        else{
          return false;
        }
      }
    }

    public synchronized final boolean tryEnter(){
      if(this.isLocked()){
        return false;
      }
      else{
        this.addLock();
        SluiceCluster[] ressource = this.getRessourceArray();
        if(Semaphor.tryEnter(ressource)){
          return true;
        }
        else{
          this.unlock();
          return false;
        }
      }
    }

    /*
     * @see org.conetex.thread.Semaphor.Semaphore#enter()
     */
    public synchronized final void enter(){
      // Siehe Kommentar zu Sluice.enter()!
      while(! this.tryEnter() ){
        try{
          this.wait();
        }
        catch(InterruptedException e){
          /** @todo behandle Exception */
        }
      }
    }

    public synchronized final void leave(){
      SluiceCluster[] ressource = getRessourceArray();
      // Entferne Lock auf die verbundenen Parent-Sluice-Objecte
      for(int i = 0; i < ressource.length; i++){
        ressource[i].leave();
      }
      // Entferne Lock auf dieses Sluice-Object
      this.unlock();
      // Siehe Kommentar zu Sluice.leave()!
      this.notify();
    }
    
    private final void removeLock(){
      synchronized(this.lock){
        this.lock.count--;
      }
      if(this.lock.count == 0){
        synchronized(this){
          try{
            this.notify();
          }
          catch(Exception e){
            /** @todo behandle Exception */
          }
        }
      }
    }

    private final void addLock(){
      synchronized(this.lock){
        this.lock.count++;
      }
    }

    private final void unlock(){
      synchronized(this.lock){
        this.lock.count--;
      }
    }

    public synchronized final void addDependingRessource(SluiceCluster managed){
      if(managed == null){
        return;
      }
      if(!this.ressourceHash.contains(managed)){
        this.ressourceHash.add(managed);
        managed.addDependencyManager(this);
      }
      this.refreshRessourceArray();
    }

    public synchronized final void removeDependingRessource(SluiceCluster managed){
      if(this.ressourceHash.contains(managed)){
        this.ressourceHash.remove(managed);
        managed.removeDependencyManager(this);
        this.refreshRessourceArray();
      }
    }    
    
    private final SluiceCluster[] getRessourceArray(){
      return this.ressource;
    }
    
    private final void refreshRessourceArray(){
      Object[] objects = this.ressourceHash.toArray();
      this.ressource = new SluiceCluster[objects.length];
      for(int i = 0; i < this.ressource.length; i++){
        this.ressource[i] = (SluiceCluster)objects[i];
      }
    }
    
    private static class Lock{
      
      private int count;
      
      private Lock(){
        this.count = 0;
      }
      
    }
    
  }

/* 
Class SluiceCluster
Deadlocks are caused by denied access on synchronized methods:

        Thread_1 ||      Thread_2
            |    ||          |
       enter|    ||          |leave
            |    ||          |
           _V_   ||         _V_
 Sluice-  |   |  ||        |   |Sluice-
 Joined_1 |___|  ||        |___|Joined_2
           / \   ||         / \
          /   \  ||<remove /   \
         /  try\ || \Lock /     \
        /  Enter>||  \   /leave  \
       V         ||  _\_V         V
   ...           || |   |           ...
                 || |___|SluiceCluster
                 ||
   Monitor       || Monitor
   SluiceJoined  || SluiceJoined
   
To prevent for deadlocks the synchronization-monitor on SluiceCluster in
methode removeLock has to been left before calling synchronized methods 
on SluiceJoined.    
*/
  public static class SluiceCluster implements Semaphore{ // RessourceDepending

    private final HashSet managerHash;

    private final Sluice delegate;

    public SluiceCluster(){
      super();
      this.managerHash = new HashSet();
      this.delegate = new Sluice();
    }

    public synchronized final boolean isLocked(){
      return this.delegate.isLocked();
    }

    public final boolean tryEnter(){
      if(!this.delegate.tryEnter()){
        return false;
      }
      Iterator i = this.managerHash.iterator();
      SluiceJoined ressource;
      while(i.hasNext()){
        ressource = (SluiceJoined)i.next();
        ressource.addLock();
      }
      return true;
    }

    public final void enter(){
      this.delegate.enter();
      Iterator i = this.managerHash.iterator();
      while(i.hasNext()){
        ((SluiceJoined)i.next()).addLock();
      }
    }

    public final void leave(){
      synchronized(this){
        if(this.delegate.isLocked()){
          this.delegate.leave();
        }
        else{
          return;
        }
      }
      Iterator i = this.managerHash.iterator();
      while(i.hasNext()){
        ((SluiceJoined)i.next()).removeLock();
      }
    }

    private synchronized final void addDependencyManager(SluiceJoined manager){
      if(!this.managerHash.contains(manager)){
        this.managerHash.add(manager);
      }
    }

    private synchronized final void removeDependencyManager(SluiceJoined manager){
      this.managerHash.remove(manager);
    }

  }

  public static void enter(Semaphore[] ressourceGroup){
    if(ressourceGroup == null || ressourceGroup.length == 0){
      return;
    }
    int master = 0;
    // setze die Master-Sperre
    ressourceGroup[master].enter();
    int i = ressourceGroup.length;
    // setze die Extra-Sperren
    loop:
    do{
      // setze Extra-Sperren hinter der Master-Sperre
      while(--i > master){
        // versuche, eine Extra-Sperre zu setzen
        if(ressourceGroup[i] != null && !ressourceGroup[i].tryEnter()){
          ressourceGroup[master].leave();
          master = i;
          // die Extra-Sperre ist nicht setzbar: entferne s�mtliche Extra-Sperren und die Master-Sperre
          while(++i < ressourceGroup.length){
            if(ressourceGroup[i] != null){
              ressourceGroup[i].leave();
            }
          }
          // setze die Master-Sperre erneut
          ressourceGroup[master].enter();
        }
      }
      // Alle Extra-Sperren hinter der Master-Sperre sind gesetzt!
      i = master;
      // setze Extra-Sperre vor der Master-Sperre
      while(--i >= 0){
        // versuche, eine Extra-Sperre zu setzen
        if(ressourceGroup[i] != null && !ressourceGroup[i].tryEnter()){
          ressourceGroup[master].leave();
          master = i;
          // die Extra-Sperre ist nicht setzbar: entferne s�mtliche Extra-Sperren und die Master-Sperre
          while(++i < ressourceGroup.length){
            if(ressourceGroup[i] != null){
              ressourceGroup[i].leave();
            }
          }
          // setze die Master-Sperre erneut
          ressourceGroup[master].enter();
          // setze die Extra-Sperren erneut. Beginne dazu von vorn!
          continue loop;
        }
      }
      // Alle Extra-Sperren vor der Master-Sperre sind gesetzt!
      break loop;
    }while(true);
  }

  public static boolean tryEnter(Semaphore[] ressourceGroup){
    // Siehe Kommentar zu Sluice.enter()!
    if(ressourceGroup == null || ressourceGroup.length == 0){
      return true;
    }
    int i;
    i = ressourceGroup.length;
    while(i-- > 0){
      if(ressourceGroup[i] != null && !ressourceGroup[i].tryEnter()){
        while(++i < ressourceGroup.length){
          ressourceGroup[i].leave();
        }
        return false;
      }
    }
    return true;
  }
  
  public static void leave(Semaphore[] ressourceGroup){
    // entferne s�mtliche Sperren
    if(ressourceGroup != null){
      for(int i = 0; i < ressourceGroup.length; i++){
        if(ressourceGroup[i] != null){
          ressourceGroup[i].leave();
        }
      }
    }
  }
  
}