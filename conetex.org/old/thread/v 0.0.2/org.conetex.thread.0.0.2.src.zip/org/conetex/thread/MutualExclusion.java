package org.conetex.thread;

import java.util.HashSet;
import java.util.Iterator;

/* Version 0.0.2 */
public class MutualExclusion{ // Semaphor
  
  public static void enter(Semaphor[] ressourceGroup){
    if(ressourceGroup == null || ressourceGroup.length == 0){
      return;
    }
    int master = 0;
    // setze die Master-Sperre
    ressourceGroup[master].enter();
    int i = ressourceGroup.length;
    // setze die Extra-Sperren
    loop:
    do{
      // setze Extra-Sperren hinter der Master-Sperre
      while(--i > master){
        // versuche, eine Extra-Sperre zu setzen
        if(ressourceGroup[i] != null && !ressourceGroup[i].tryEnter()){
          ressourceGroup[master].leave();
          master = i;
          // die Extra-Sperre ist nicht setzbar: entferne s�mtliche Extra-Sperren und die Master-Sperre
          while(++i < ressourceGroup.length){
            if(ressourceGroup[i] != null){
              ressourceGroup[i].leave();
            }
          }
          // setze die Master-Sperre erneut
          ressourceGroup[master].enter();
        }
      }
      // Alle Extra-Sperren hinter der Master-Sperre sind gesetzt!
      i = master;
      // setze Extra-Sperre vor der Master-Sperre
      while(--i >= 0){
        // versuche, eine Extra-Sperre zu setzen
        if(ressourceGroup[i] != null && !ressourceGroup[i].tryEnter()){
          ressourceGroup[master].leave();
          master = i;
          // die Extra-Sperre ist nicht setzbar: entferne s�mtliche Extra-Sperren und die Master-Sperre
          while(++i < ressourceGroup.length){
            if(ressourceGroup[i] != null){
              ressourceGroup[i].leave();
            }
          }
          // setze die Master-Sperre erneut
          ressourceGroup[master].enter();
          // setze die Extra-Sperren erneut. Beginne dazu von vorn!
          continue loop;
        }
      }
      // Alle Extra-Sperren vor der Master-Sperre sind gesetzt!
      break loop;
    }while(true);
  }

  public static boolean tryEnter(Semaphor[] ressourceGroup){
    // Siehe Kommentar zu Sluice.enter()!
    if(ressourceGroup == null || ressourceGroup.length == 0){
      return true;
    }
    int i;
    i = ressourceGroup.length;
    while(i-- > 0){
      if(ressourceGroup[i] != null && !ressourceGroup[i].tryEnter()){
        while(++i < ressourceGroup.length){
          ressourceGroup[i].leave();
        }
        return false;
      }
    }
    return true;
  }
  
  public static void leave(Semaphor[] ressourceGroup){
    // entferne s�mtliche Sperren
    if(ressourceGroup != null){
      for(int i = 0; i < ressourceGroup.length; i++){
        if(ressourceGroup[i] != null){
          ressourceGroup[i].leave();
        }
      }
    }
  }

  public static interface Semaphor{ // Ressource

    public boolean isLocked();

    public boolean tryEnter();

    public void enter();

    public void leave();

  }

  /*
  class Sluice
  the following Example shows the prozessing of two Threads entering a sluice:
  ................... ................... ...................
  : A               : : B               : : C               :
  :                 : :                 : :                 :
  :   ___________   : :   ___________   : :   ___________   :
  :  ||---------||  : :  ||---------||  : :  ||---------||  :
  :  ||         ||  : :  ||         ||  : :  ||    _    ||  :
  :  ||         ||  : :  ||         ||  : :  ||   / \   ||  :
  :  ||         ||  : :  ||         ||  : :  ||   |T|   ||  :
  :  ||         ||  : :  ||         ||  : :  ||   |H|   ||  :
  :  ||         ||  : :  ||         ||  : :  ||   |R|   ||  :
  :  ||         ||  : :  ||         ||  : :  ||   |E|   ||  :
  :  ||         ||  : :  ||         ||  : :  ||   |A|   ||  :
  :  ||         ||  : :  ||         ||  : :  ||   |D|   ||  :
  :  ||         ||  : :  ||    _    ||  : :  ||   | |   ||  :
  :  ||         ||  : :  ||   / \   ||  : :  ||   |1|   ||  :
  :  ||         ||  : :  ||   |T|   ||  : :  ||   |_|   ||  :
  :  ||_________||  : :  ||   |H|   ||  : :  ||_________||  :
  :   -----------   : :  \\   |R|   //  : :   -----------   :
  :                 : :   \\  |E|  //   : :        _        :
  :                 : :    \\ |A| //    : :       / \       :
  :      _   _      : :       |D|  _    : :       |T|       :
  :     / \ / \     : :       | | / \   : :       |H|       :
  :     |T| |T|     : :       |1| |T|   : :       |R|       :
  :     |H| |H|     : :       |_| |H|   : :       |E|       :
  :     |R| |R|     : :           |R|   : :       |A|       :
  :     |E| |E|     : :           |E|   : :       |D|       :
  :     |A| |A|     : :           |A|   : :       | |       :
  :     |D| |D|     : :           |D|   : :       |2|       :
  :     | | | |     : :           | |   : :       |_|       :
  :     |1| |2|     : :           |2|   : :                 :
  :     |_| |_|     : :           |_|   : :                 :
  :.................: :.................: :.................:
  ................... ................... ...................
  : D               : : E               : : F      _        :
  :                 : :                 : :       / \       :
  :                 : :        _        : :       |T|       :
  :                 : :       / \       : :       |H|       :
  :                 : :       |T|       : :       |R|       :
  :                 : :       |H|       : :       |E|       :
  :        _        : :       |R|       : :       |A|       :
  :       / \       : :       |E|       : :       |D|       :
  :       |T|       : :       |A|       : :       | |       :
  :       |H|       : :       |D|       : :       |1|       :
  :       |R|       : :       | |       : :       |_|       :
  :    // |E| \\    : :       |1|       : :                 :
  :   //  |A|  \\   : :       |_|       : :                 :
  :  //   |D|   \\  : :   ___________   : :   ___________   :
  :  ||   | |   ||  : :  ||---------||  : :  ||---------||  :
  :  ||   |1|   ||  : :  ||         ||  : :  ||         ||  :
  :  ||   |_|   ||  : :  ||         ||  : :  ||         ||  :
  :  ||         ||  : :  ||         ||  : :  ||         ||  :
  :  ||         ||  : :  ||         ||  : :  ||         ||  :
  :  ||         ||  : :  ||         ||  : :  ||         ||  :
  :  ||         ||  : :  ||         ||  : :  ||         ||  :
  :  ||         ||  : :  ||         ||  : :  ||         ||  :
  :  ||         ||  : :  ||         ||  : :  ||         ||  :
  :  ||         ||  : :  ||         ||  : :  ||         ||  :
  :  ||         ||  : :  ||         ||  : :  ||    _    ||  :
  :  ||         ||  : :  ||         ||  : :  ||   / \   ||  :
  :  ||_________||  : :  ||_________||  : :  ||   |T|   ||  :
  :   -----------   : :   -----------   : :  \\   |H|   //  :
  :        _        : :        _        : :   \\  |R|  //   :
  :       / \       : :       / \       : :    \\ |E| //    :
  :       |T|       : :       |T|       : :       |A|       :
  :       |H|       : :       |H|       : :       |D|       :
  :       |R|       : :       |R|       : :       | |       :
  :       |E|       : :       |E|       : :       |2|       :
  :       |A|       : :       |A|       : :       |_|       :
  :       |D|       : :       |D|       : :                 :
  :       | |       : :       | |       : :                 :
  :       |2|       : :       |2|       : :                 :
  :       |_|       : :       |_|       : :                 :
  :                 : :                 : :                 :
  :                 : :                 : :                 :
  :.................: :.................: :.................:
  ................... ................... ...................
  : G      _        : : H  _            : : I    _   _      :
  :       / \       : :   / \           : :     / \ / \     :
  :       |T|       : :   |T|           : :     |T| |T|     :
  :       |H|       : :   |H|           : :     |H| |H|     :
  :       |R|       : :   |R|           : :     |R| |R|     :
  :       |E|       : :   |E|           : :     |E| |E|     :
  :       |A|       : :   |A|  _        : :     |A| |A|     :
  :       |D|       : :   |D| / \       : :     |D| |D|     :
  :       | |       : :   | | |T|       : :     | | | |     :
  :       |1|       : :   |1| |H|       : :     |1| |2|     :
  :       |_|       : :   |_| |R|       : :     |_| |_|     :
  :                 : :    // |E| \\    : :                 :
  :                 : :   //  |A|  \\   : :                 :
  :   ___________   : :  //   |D|   \\  : :   ___________   :
  :  ||---------||  : :  ||   | |   ||  : :  ||---------||  :
  :  ||    _    ||  : :  ||   |2|   ||  : :  ||         ||  :
  :  ||   / \   ||  : :  ||   |_|   ||  : :  ||         ||  :
  :  ||   |T|   ||  : :  ||         ||  : :  ||         ||  :
  :  ||   |H|   ||  : :  ||         ||  : :  ||         ||  :
  :  ||   |R|   ||  : :  ||         ||  : :  ||         ||  :
  :  ||   |E|   ||  : :  ||         ||  : :  ||         ||  :
  :  ||   |A|   ||  : :  ||         ||  : :  ||         ||  :
  :  ||   |D|   ||  : :  ||         ||  : :  ||         ||  :
  :  ||   | |   ||  : :  ||         ||  : :  ||         ||  :
  :  ||   |2|   ||  : :  ||         ||  : :  ||         ||  :
  :  ||   |_|   ||  : :  ||         ||  : :  ||         ||  :
  :  ||_________||  : :  ||_________||  : :  ||_________||  :
  :   -----------   : :   -----------   : :   -----------   :
  :                 : :                 : :                 :
  :.................: :.................: :.................:
  */
  public static class Sluice implements Semaphor{ // RessourceSingle

    /*
     * Flag zur Darstellung der Zugriffserlaubnis.
     * Wenn 'locked == true' ist der Zugriff verboten.
     * Wenn 'locked == false' ist der Zugriff erlaubt.
     */
    private boolean locked;

    public Sluice(){
      this.locked = false;
    }

    public final synchronized boolean tryEnter(){
      if(this.locked){
        return false;
      }
      this.locked = true;
      return true;
    }

    /*
     *   Der aktuell aufrufende Thread betritt hier den durch den Semaphor
     *   gesch�tzten Bereich.
     */
    public final synchronized void enter(){
      ////System.out.println("enter   ");
      while(this.locked){
        //// 'locked == true' zeigt an, dass die Semaphor-Sperre bereits gesetzt
        //// wurde. Der aktuell aufrufende Thread wartet daher und verl�sst
        //// nicht diese Methode, um die Verarbeitung fortzusetzen. Erst wenn der
        //// Thread, der die Semaphor-Sperre setzte, den gesch�tzten Bereich
        //// mit dem Aufruf von 'leave()' verl�sst, wird einer der wartenden
        //// Threads wieder aktiviert.
        // Im Detail:
        // Der aktuell aufrufende Thread wird hier durch den Aufruf von wait(),
        // in die Warteliste des Semaphor-Objects aufgenommen. Dadurch wird er
        // unterbrochen und im Scheduler als wartend markiert. Erst der Aufruf
        // von 'notify()' in 'leave()' entfernt einen beliebigen Prozess aus der
        // Warteliste des Semaphor-Objekts und f�hrt ihn normalem Scheduling zu.
        ////System.out.println("Boom " + this.toString());
        try{
          this.wait();
        }
        catch(InterruptedException e){
          /** @todo wie ist diese Exception hier zu behandeln? */
        }
      }
      ////////////////////////////////////////////////////////////////////////////
      // Der folgende Abschnitt kann unter zweierlei
      // Umst�nden betreten werden:
      // A. Der vorstehende Block wurde durch den aktuellen Thread betreten,
      //    da 'locked == true'. Wegen des Aufrufs von 'wait()' wartete dieser
      //    Thread zun�chst, ist nun aber durch den Aufruf von 'notify()' wieder
      //    aktiviert worden, so dass er obigen Block verlie� und den folgenden
      //    Abschnitt betritt. Kann obiger Block verlassen werden, wenn
      //    'locked == true' (dies ist der Fall bei einem 'if'-Block, der ja
      //    'locked' nur beim Betreten, nicht aber beim Verlassen ausgewertet
      //    wird), so k�nnte betreffender Thread den gesch�tzten Bereich
      //    betreten, obwohl dieser durch 'locked' noch immer als gesperrt
      //    gekennzeichnet ist. Dies l��t sich durch die Verwendung eines
      //    'while'-Blocks statt eines 'if'-Blocks einfach verhindern.
      //    Im Detail:
      //    Wird ein 'if'-Block verwendet, so kann ein Thread, der im Wettbewerb
      //    um das Betreten der 'synchronized'-Bl�cke zun�chst gegen den
      //    aufgeweckten Thread gewonnen hatte und somit den folgenden Abschnitt
      //    betritt, 'locked' auf 'true' setzen. Verl��t dieser Gewinner-Thread
      //    daraufhin den 'synchronized'-Block, um Bearbeitungen nach 'enter()'
      //    durchzuf�hren, so erh�lt nun der geweckte Thread den Monitor 'this'
      //    und f�hrt die Bearbeitung von 'enter()' fort, obwohl der Gewinner-
      //    Thread die zu sch�tztende Sluice noch nicht durch den Aufruf von
      //    'leave()' freigegeben hatte.
      // B. Der vorstehende Block wurde nicht betreten, da 'locked == false'.
      //    'locked == false' zeigt an, dass die Semaphor-Sperre noch nicht
      //    gesetzt wurde. Der aktuell aufrufende Thread wartet daher nicht und
      //    verl��t diese Methode, um die Verarbeitung fortzusetzen.
      ////////////////////////////////////////////////////////////////////////////
      // Gilt nun, dass
      // 1. nur ein Thread den folgenden Abschnitt betritt,
      // 2. die Semaphor-Sperre legal aufghoben ist, also 'locked' legal auf
      //    'false' gesetzt wurde,
      // so sichert die folgende Anweisung die Konsistenz der Semaphor-Sperre:
      //// Um Threads warten zu lassen, die im Folgendem diese Methode betreten
      //// bevor der aktuelle aufrufende Thread den durch den Semaphor den
      //// gesch�tzten Bereich mit dem Aufruf von 'leave()' verl��t, wird die
      //// Semaphor-Sperre nun gesetzt. Dazu wird 'locked' auf 'true' gesetzt.
      this.locked = true;
    }

    /*
     *   Der aktuell aufrufende Thread verl��t hier
     *   den durch den Semaphor gesch�tzten Bereich.
     */
    public final synchronized void leave(){
      //// Um Threads im Folgendem zu erlauben, die
      //// Verarbeitung nach dem Betreten von 'enter()'
      //// fortzusetzen, wird die Semaphor-Sperre
      //// entfernt, das hei�t 'locked' wird auf
      //// 'false' gesetzt.
      this.locked = false;
      //// Da die Sperre nun entfernt ist, kann jetzt
      //// eine eventuell wartender Thread aktiviert werden.
      // Da diese Methode als 'synchronized' deklariert ist,
      // bleibt sichergestellt, dass kein weiterer Thread
      // Code dieses Semaphor-Objects ausf�hren kann und
      // so wegen der oben gerade aufgehobenen Sperre
      // gleichzeitig mit dem eventuell gleich per 'notify()'
      // wieder aktivierten Thread den zu sch�tzenden
      // Bereich betritt.
      this.notify();
    }

    public final synchronized boolean isLocked(){
      return this.locked;
    }
    
  }

  /* 
  Class SluiceJoined
  Deadlocks are caused by denied access on synchronized methods:

          Thread_1 ||      Thread_2
              |    ||          |
         enter|    ||          |leave
              |    ||          |
             _V_   ||         _V_
   Sluice-  |   |  ||        |   |Sluice-
   Joined_1 |___|  ||        |___|Joined_2
             / \   ||         / \
            /   \  ||<remove /   \
           /  try\ || \Lock /     \
          /  Enter>||  \   /leave  \
         V         ||  _\_V         V
     ...           || |   |           ...
                   || |___|SluiceCluster
                   ||
     Monitor       || Monitor
     SluiceCluster || SluiceCluster
     
  To prevent for deadlocks the synchronization-monitor on SluiceJoined in
  methode removeLock has to been left before calling synchronized methods 
  on SluiceCluster.    
  */
  public static class SluiceJoined implements Semaphor{ // RessourceDepending

    private final HashSet managingSluiceClusterHash;

    private final Sluice delegate;

    public SluiceJoined(){
      super();
      this.managingSluiceClusterHash = new HashSet();
      this.delegate = new Sluice();
    }

    public synchronized final boolean isLocked(){
      return this.delegate.isLocked();
    }

    public final boolean tryEnter(){
      if(!this.delegate.tryEnter()){
        return false;
      }
      Iterator i = this.managingSluiceClusterHash.iterator();
      SluiceCluster ressource;
      while(i.hasNext()){
        ressource = (SluiceCluster)i.next();
        ressource.addLock();
      }
      return true;
    }

    public final void enter(){
      this.delegate.enter();
      Iterator i = this.managingSluiceClusterHash.iterator();
      while(i.hasNext()){
        ((SluiceCluster)i.next()).addLock();
      }
    }
    
    public final void leave(){
      synchronized(this){
        if(this.delegate.isLocked()){
          this.delegate.leave();
        }
        else{
          return;
        }
      }
      Iterator i = this.managingSluiceClusterHash.iterator();
      while(i.hasNext()){
        ((SluiceCluster)i.next()).removeLock();
      }
    }

    private synchronized final void addManagingSluiceCluster(SluiceCluster manager){
      if(!this.managingSluiceClusterHash.contains(manager)){
        this.managingSluiceClusterHash.add(manager);
      }
    }

    private synchronized final void removeManagingSluiceCluster(SluiceCluster manager){
      this.managingSluiceClusterHash.remove(manager);
    }

  }
  
  /*
  Class SluiceCluster
  The Mutual Exclusion of Access to more than one depending Sluices is managed
  by an Object of class SluiceCluster. 
  the following Example shows the prozessing of three Threads entering two 
  joined Sluices: 
  .............................. .............................. .............................. 
  : A    Status: not locked    : : B    Status: locked        : : C                          : 
  :                            : :                            : :                            : 
  :       //          \\       : :                            : :                            : 
  :      //            \\      : :                            : :                            : 
  :     //              \\     : :                            : :                            : 
  :    //                \\    : :                            : :                            : 
  :   //                  \\   : :   ______________________   : :   ______________________   : 
  :  |/                    \|  : :  ||--------------------||  : :  ||--------------------||  : 
  :  ||                    ||  : :  ||                    ||  : :  ||                    ||  : 
  :  ||   SluiceCluster    ||  : :  ||                    ||  : :  ||               _    ||  : 
  :  ||                    ||  : :  ||                    ||  : :  ||              / \   ||  : 
  :  ||                    ||  : :  ||                    ||  : :  ||              |T|   ||  : 
  :  ||//     \\  //     \\||  : :  ||                    ||  : :  ||//     \\  // |H| \\||  : 
  :  |//       \\//       \\|  : :  ||____________________||  : :  |//       \\//  |R|  \\|  : 
  :  |/         \/         \|  : :  ||---------||---------||  : :  |/         \/   |E|   \|  : 
  :  || Sluice  || Sluice  ||  : :  ||         ||         ||  : :  ||         ||   |A|   ||  : 
  :  ||   1     ||   2     ||  : :  ||         ||         ||  : :  ||         ||   |D|   ||  : 
  :  ||         ||         ||  : :  ||         ||         ||  : :  ||         ||   | |   ||  : 
  :  ||//     \\||//     \\||  : :  ||         ||         ||  : :  ||         ||// |2| \\||  : 
  :  |//       \\//       \\|  : :  ||_________||_________||  : :  ||_________|//  |_|  \\|  : 
  :  |/         \/         \|  : :  |----------------------|  : :  |-----------/         \|  : 
  :                            : :      _          _   _      : :        _            _      : 
  :  Status not locked         : :     / \        / \ / \     : :       / \          / \     : 
  :                            : :     |T|        |T| |T|     : :       |T|          |T|     : 
  :                            : :     |H|        |H| |H|     : :       |H|          |H|     : 
  :                            : :     |R|        |R| |R|     : :       |R|          |R|     : 
  :                            : :     |E|        |E| |E|     : :       |E|          |E|     : 
  :                            : :     |A|        |A| |A|     : :       |A|          |A|     : 
  :                            : :     |D|        |D| |D|     : :       |D|          |D|     : 
  :                            : :     | |        | | | |     : :       | |          | |     : 
  :                            : :     |1|        |2| |3|     : :       |1|          |3|     : 
  :                            : :     |_|        |_| |_|     : :       |_|          |_|     : 
  :............................: :............................: :............................: 
  .............................. .............................. ..............................  
  : D                          : : E                          : : F                 _        :  
  :                            : :                            : :                  / \       :                                                                                            
  :                            : :                            : :                  |T|       :                                                                                            
  :                            : :                            : :                  |H|       : 
  :                            : :                            : :                  |R|       :  
  :                            : :                            : :                  |E|       :  
  :                            : :                   _        : :                  |A|       :  
  :                            : :                  / \       : :                  |D|       :  
  :                            : :      //          |T|       : :                  | |       :  
  :                            : :     //           |H| \     : :                  |2|       :  
  :                            : :    //            |R| \\    : :                  |_|       :  
  :   ______________________   : :   //             |E|  \\   : :   ______________________   :  
  :  ||--------------------||  : :  |/              |A|   \|  : :  ||--------------------||  :  
  :  ||               _    ||  : :  ||              |D|   ||  : :  ||                    ||  :  
  :  ||              / \   ||  : :  ||              | |   ||  : :  ||                    ||  :  
  :  ||              |T|   ||  : :  ||              |2|   ||  : :  ||                    ||  :  
  :  ||              |H|   ||  : :  ||              |_|   ||  : :  ||                    ||  :  
  :  ||//     \\  // |R| \\||  : :  ||//     \\  //     \\||  : :  ||                    ||  :  
  :  |//       \\//  |E|  \\|  : :  |//       \\//       \\|  : :  ||_________  _________||  :  
  :  |/         \/   |A|   \|  : :  |/         \/         \|  : :  ||---------||---------||  :  
  :  ||         ||   |D|   ||  : :  ||         ||         ||  : :  ||         ||         ||  :  
  :  ||         ||   | |   ||  : :  ||         ||         ||  : :  ||         ||         ||  :  
  :  ||         ||   |2|   ||  : :  ||         ||         ||  : :  ||         ||         ||  :  
  :  ||         ||   |_|   ||  : :  ||         ||         ||  : :  ||         ||         ||  :  
  :  ||_________||_________||  : :  ||_________||_________||  : :  ||_________||_________||  :  
  :  |----------------------|  : :  |----------------------|  : :  |----------------------|  :  
  :       _             _      : :       _             _      : :      _              _      :  
  :      / \           / \     : :      / \           / \     : :     / \            / \     :  
  :      |T|           |T|     : :      |T|           |T|     : :     |T|            |T|     :  
  :      |H|           |H|     : :      |H|           |H|     : :     |H|            |H|     :  
  :      |R|           |R|     : :      |R|           |R|     : :     |R|            |R|     :  
  :      |E|           |E|     : :      |E|           |E|     : :     |E|            |E|     :  
  :      |A|           |A|     : :      |A|           |A|     : :     |A|            |A|     :  
  :      |D|           |D|     : :      |D|           |D|     : :     |D|            |D|     : 
  :      | |           | |     : :      | |           | |     : :     | |            | |     : 
  :      |1|           |3|     : :      |1|           |3|     : :     |1|            |3|     : 
  :      |_|           |_|     : :      |_|           |_|     : :     |_|            |_|     : 
  :............................: :............................: :............................: 
  .............................. .............................. .............................. 
  : G                          : : H                          : : I                 _        : 
  :                            : :                  _         : :                  / \       : 
  :                 _          : :                 / \        : :                  |T|       : 
  :                / \         : :                 |T|        : :                  |H|       : 
  :                |T|         : :                 |H|        : :                  |R|       : 
  :                |H|         : :                 |R|        : :                  |E|       : 
  :                |R|         : :                 |E|        : :                  |A|       : 
  :                |E|         : :                 |A|        : :                  |D|       : 
  :                |A|         : :                 |D|        : :                  | |       : 
  :                |D|         : :                 | |        : :                  |2|       : 
  :                | |         : :                 |2|        : :        _         |_|       : 
  :                |2|         : :                 |_|        : :       / \                  : 
  :                |_|         : :                            : :       |T|          \\      : 
  :                            : :                            : :     / |H|           \\     : 
  :                            : :                            : :    // |R|            \\    : 
  :   ______________________   : :   ______________________   : :   //  |E|             \\   : 
  :  ||--------------------||  : :  ||--------------------||  : :  |/   |A|              \|  : 
  :  ||                    ||  : :  ||    _               ||  : :  ||   |D|              ||  : 
  :  ||    _               ||  : :  ||   / \              ||  : :  ||   | |              ||  : 
  :  ||   / \              ||  : :  ||   |T|              ||  : :  ||   |1|              ||  : 
  :  ||   |T|              ||  : :  ||   |H|              ||  : :  ||   |_|              ||  : 
  :  ||// |H| \\           ||  : :  ||// |R| \\           ||  : :  ||//     \\  //     \\||  : 
  :  |//  |R|  \\ _________||  : :  |//  |E|  \\ _________||  : :  |//       \\//       \\|  : 
  :  |/   |E|   \|---------||  : :  |/   |A|   \|---------||  : :  |/         \/         \|  : 
  :  ||   |A|   ||         ||  : :  ||   |D|   ||         ||  : :  ||         ||         ||  : 
  :  ||   |D|   ||         ||  : :  ||   | |   ||         ||  : :  ||         ||         ||  : 
  :  ||   | |   ||         ||  : :  ||   |1|   ||         ||  : :  ||         ||         ||  : 
  :  ||// |1| \\||         ||  : :  ||   |_|   ||         ||  : :  ||         ||         ||  : 
  :  |//  |_|  \\|_________||  : :  ||_________||_________||  : :  ||_________||_________||  : 
  :  |/         \-----------|  : :  |----------------------|  : :  |----------------------|  : 
  :                     _      : :                     _      : :                   _        : 
  :                    / \     : :                    / \     : :                  / \       : 
  :                    |T|     : :                    |T|     : :                  |T|       : 
  :                    |H|     : :                    |H|     : :                  |H|       : 
  :                    |R|     : :                    |R|     : :                  |R|       : 
  :                    |E|     : :                    |E|     : :                  |E|       : 
  :                    |A|     : :                    |A|     : :                  |A|       : 
  :                    |D|     : :                    |D|     : :                  |D|       : 
  :                    | |     : :                    | |     : :                  | |       : 
  :                    |3|     : :                    |3|     : :                  |3|       : 
  :                    |_|     : :                    |_|     : :                  |_|       : 
  :............................: :............................: :............................: 
  .............................. .............................. .............................. 
  : J                 _        : : K                  _       : : L                   _      : 
  :                  / \       : :                   / \      : :                    / \     : 
  :                  |T|       : :                   |T|      : :       _            |T|     : 
  :                  |H|       : :        _          |H|      : :      / \           |H|     : 
  :        _         |R|       : :       / \         |R|      : :      |T|           |R|     : 
  :       / \        |E|       : :       |T|         |E|      : :      |H|           |E|     : 
  :       |T|        |A|       : :       |H|         |A|      : :      |R|           |A|     : 
  :       |H|        |D|       : :       |R|         |D|      : :      |E|           |D|     : 
  :       |R|        | |       : :       |E|         | |      : :      |A|           | |     : 
  :       |E|        |2|       : :       |A|         |2|      : :      |D|           |2|     : 
  :       |A|        |_|       : :       |D|         |_|      : :      | |           |_|     : 
  :       |D|                  : :       | |                  : :      |1|                   : 
  :       | |                  : :       |1|                  : :      |_|                   : 
  :       |1|                  : :       |_|                  : :                            : 
  :       |_|                  : :                            : :                            : 
  :   ______________________   : :   ______________________   : :   ______________________   : 
  :  ||--------------------||  : :  ||--------------------||  : :  ||--------------------||  : 
  :  ||                    ||  : :  ||                    ||  : :  ||               _    ||  : 
  :  ||                    ||  : :  ||               _    ||  : :  ||              / \   ||  : 
  :  ||                    ||  : :  ||              / \   ||  : :  ||              |T|   ||  : 
  :  ||                    ||  : :  ||              |T|   ||  : :  ||              |H|   ||  : 
  :  ||                    ||  : :  ||//     \\  // |H| \\||  : :  ||//     \\  // |R| \\||  : 
  :  ||_________  _________||  : :  |//       \\//  |R|  \\|  : :  |//       \\//  |E|  \\|  : 
  :  ||---------||---------||  : :  |/         \/   |E|   \|  : :  |/         \/   |A|   \|  : 
  :  ||         ||         ||  : :  ||         ||   |A|   ||  : :  ||         ||   |D|   ||  : 
  :  ||         ||         ||  : :  ||         ||   |D|   ||  : :  ||         ||   | |   ||  : 
  :  ||         ||         ||  : :  ||         ||   | |   ||  : :  ||         ||   |3|   ||  : 
  :  ||         ||         ||  : :  ||         ||// |3| \\||  : :  ||         ||   |_|   ||  : 
  :  ||_________||_________||  : :  ||_________|//  |_|  \\|  : :  ||_________||_________||  : 
  :  |----------------------|  : :  |-----------/         \|  : :  |----------------------|  : 
  :                   _        : :                            : :                            : 
  :                  / \       : :                            : :                            : 
  :                  |T|       : :                            : :                            : 
  :                  |H|       : :                            : :                            :
  :                  |R|       : :                            : :                            :
  :                  |E|       : :                            : :                            :
  :                  |A|       : :                            : :                            :
  :                  |D|       : :                            : :                            :
  :                  | |       : :                            : :                            :
  :                  |3|       : :                            : :                            :
  :                  |_|       : :                            : :                            :
  :............................: :............................: :............................:
  .............................. ..............................
  : M     _              _     : : N      _             _     :
  :      / \            / \    : :       / \           / \    :
  :      |T|            |T|    : :       |T|           |T|    :
  :      |H|            |H|    : :       |H|           |H|    :
  :      |R|            |R|    : :       |R|        _  |R|    :
  :      |E|            |E|    : :       |E|       / \ |E|    :
  :      |A|            |A|    : :       |A|       |T| |A|    :
  :      |D|            |D|    : :       |D|       |H| |D|    :
  :      | |            | |    : :       | |       |R| | |    :
  :      |1|            |2|    : :       |1|       |E| |2|    :
  :      |_|          _ |_|    : :       |_|       |A| |_|    :
  :                  / \       : :                 |D|        :
  :      //          |T|       : :                 | |        :
  :     //           |H| \     : :                 |3|        :
  :    //            |R| \\    : :                 |_|        :
  :   //             |E|  \\   : :   ______________________   :
  :  |/              |A|   \|  : :  ||--------------------||  :
  :  ||              |D|   ||  : :  ||                    ||  :
  :  ||              | |   ||  : :  ||                    ||  :
  :  ||              |3|   ||  : :  ||                    ||  :
  :  ||              |_|   ||  : :  ||                    ||  :
  :  ||//     \\  //     \\||  : :  ||                    ||  :
  :  |//       \\//       \\|  : :  ||_________  _________||  :
  :  |/         \/         \|  : :  ||---------||---------||  :
  :  ||         ||         ||  : :  ||         ||         ||  :
  :  ||         ||         ||  : :  ||         ||         ||  :
  :  ||         ||         ||  : :  ||         ||         ||  :
  :  ||         ||         ||  : :  ||         ||         ||  :
  :  ||_________||_________||  : :  ||_________||_________||  :
  :  |----------------------|  : :  |----------------------|  :
  :                            : :                            :
  :                            : :                            :
  :............................: :............................:
  
  SluiceClusters interact with there depending SluiceJoined in the following
  monitor-synchronized way:
      _________________       _________________       __________________
  =  | Monitor         |     | Monitor         |     | Monitor          |
  =  | SluiceCluster   |     | Lock            |     | SluiceJoined     |
  =  |    _____________|_____|_      ________  |     |                  |
     |   | enter       |     | |...>|isLocked| |     |                  |
  t  |   |             |     | |    |________| |     |      __________  |
  i  |   |             |     | |..........................>| tryEnter | |
  m  |   |             |    _|_|..........................>|          | |
  e  |   |             |   | |                 |  ___|_____|          | |
     |   |             |   | |    _______     _|_|  _|________________| |
  =  |   |             |   | |   |addLock|<..| |   | |                  |
  =  |   |             |   |_|_  |_______|   |_|___| |                  |
  =  |   |             |     | |....................................... |
  =  |   |_____________|_ w _|_|..................................... : |
  =  |      ________   | |a| |                 |     |              : : |
  =  | ...>| notify |  | |i| |                 |     |              : : |
  =  | :   |________|...>|t| |                 |     |              : : |
  =  | :  _____________|_|e|_|_      ________  |     |              : : |
  =  | : |             |     | |...>| addLock| |     |              : : |
  =  | : |_____________|_____|_|    |________| |     |              : : |
  V  |_:_______________|     |_________________|     |______________:_:_|
      _:_______________       _________________       ______________:_:_
  =  | : Monitor       |     | Monitor         |     | Monitor      : : |
  =  | : Res.Managed   |     | Lock            |     | Res.Depending: : |
  =  | :  _____________|_____|_                |     |     _____    : : |
     | : | leave       |     | |.........................>|leave|<..: : |
  t  | : |         ____|_____|_|.........................>|     |<....: |
  i  | : |        |    |     |                 |  ___|____|     |       |
  m  | : |        |    |  ___|__________      _|_|  _|__________|       |
  e  | : |        |   _|_|   |removeLock|<...| |   | |                  |
     | : |        |  | |    _|__________|    |_|___| |                  |
  =  | :.............|_|___| |                 |     |                  |
  =  | : |        |____|_____|_      ________  |     |                  |
  =  | : |             |     | |...>| unlock | |     |                  |
  =  | :.|_____________|_____|_|    |________| |     |                  |
  V  |_________________|     |_________________|     |__________________|

  */  
  public static class SluiceCluster implements Semaphor{ // RessourceManaged

    private Lock lock;
    
    private SluiceJoined[] sluices;
    
    private final HashSet sluicesHash;

    public SluiceCluster(){
      this.lock = new Lock();
      this.sluicesHash = new HashSet();
    }
    
    public SluiceCluster(SluiceJoined[] managed){
      this.lock = new Lock();
      this.sluicesHash = new HashSet();
      if(managed != null){
        for(int i = 0; i < managed.length; i++){
          this.addSluice(managed[i]);
        }
      }
    }

    public final boolean isLocked(){
      synchronized(this.lock){
        if(this.lock.count > 0){
          return true;
        }
        else{
          return false;
        }
      }
    }

    public synchronized final boolean tryEnter(){
      if(this.isLocked()){
        return false;
      }
      else{
        this.addLock();
        SluiceJoined[] ressource = this.getSluicesJoined();
        if(MutualExclusion.tryEnter(ressource)){
          return true;
        }
        else{
          this.unlock();
          return false;
        }
      }
    }

    /*
     * @see org.conetex.thread.MutualExclusion.Semaphor#enter()
     */
    public synchronized final void enter(){
      // Siehe Kommentar zu Sluice.enter()!
      while(! this.tryEnter() ){
        try{
          this.wait();
        }
        catch(InterruptedException e){
          /** @todo behandle Exception */
        }
      }
    }

    public synchronized final void leave(){
      // Entferne Lock auf die verbundenen Sluice-Objecte
      this.leave(this.getSluicesJoined());
      // Entferne Lock auf dieses Sluice-Object
      this.unlock();
      // Siehe Kommentar zu Sluice.leave()!
      this.notify();
    }

    private void leave(SluiceJoined[] ressource){
      // Entferne Lock auf die verbundenen Sluice-Objecte
      if(ressource != null){
        for(int i = 0; i < ressource.length; i++){
          ressource[i].leave();
        }
      }
    }
    
    private final void removeLock(){
      synchronized(this.lock){
        this.lock.count--;
      }
      if(this.lock.count == 0){
        synchronized(this){
          try{
            this.notify();
          }
          catch(Exception e){
            /** @todo behandle Exception */
          }
        }
      }
    }

    private final void addLock(){
      synchronized(this.lock){
        this.lock.count++;
      }
    }

    private final void unlock(){
      synchronized(this.lock){
        this.lock.count--;
      }
    }

    public synchronized final void addSluice(SluiceJoined managed){
      if(managed == null){
        return;
      }
      if(this.sluicesHash.contains(managed)){
        return;
      }
      // Setze Lock auf dieses Sluice-Object und die bisherigen Cluster-Member
      this.enter();
      // Speichere den Stand bisheriger Cluster-Member
      SluiceJoined[] ressource = this.getSluicesJoined();
      // neue Sluice hinzuf�gen      
      this.sluicesHash.add(managed);
      managed.addManagingSluiceCluster(this);
      // Bereite n�chstes Enter vor
      this.refreshSluices();
      // Entferne Locks der bisherigen Cluster-Member
      this.leave(ressource);
      // Entferne Lock auf dieses Sluice-Object
      this.unlock();
      // Siehe Kommentar zu Sluice.leave()!
      this.notify();
    }

    public synchronized final void removeSluice(SluiceJoined managed){
      if(managed == null){
        return;
      }
      if(!this.sluicesHash.contains(managed)){
        return;
      }
      // Setze Lock auf dieses Sluice-Object und die bisherigen Cluster-Member
      this.enter();
      // Speichere den Stand bisheriger Cluster-Member
      SluiceJoined[] ressource = this.getSluicesJoined();
      // Sluice entfernen      
      this.sluicesHash.remove(managed);
      managed.removeManagingSluiceCluster(this);
      // Bereite n�chstes Enter vor
      this.refreshSluices();
      // Entferne Locks der bisherigen Cluster-Member
      this.leave(ressource);
      // Entferne Lock auf dieses Sluice-Object
      this.unlock();
      // Siehe Kommentar zu Sluice.leave()!
      this.notify();
    }    
    
    private final SluiceJoined[] getSluicesJoined(){
      return this.sluices;
    }

    public final SluiceJoined[] getSluices(){
      SluiceJoined[] source = this.getSluicesJoined();
      SluiceJoined[] target = new SluiceJoined[source.length];
      System.arraycopy(source, 0, target, 0, source.length);
      return target;
    }
    
    private final void refreshSluices(){
      Object[] objects = this.sluicesHash.toArray();
      this.sluices = new SluiceJoined[objects.length];
      for(int i = 0; i < this.sluices.length; i++){
        this.sluices[i] = (SluiceJoined)objects[i];
      }
    }
    
    private static class Lock{
      
      private int count;
      
      private Lock(){
        this.count = 0;
      }
      
    }
    
  }

}