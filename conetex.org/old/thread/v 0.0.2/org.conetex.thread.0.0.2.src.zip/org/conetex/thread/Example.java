package org.conetex.thread;

import java.io.IOException;
import org.conetex.thread.MutualExclusion.SluiceCluster;

public class Example{
  
  final static String STATUS_WAITING =  "waiting ";
  final static String STATUS_EATING =   "eating  ";
  final static String STATUS_SLEEPING = "sleeping";
  final static int STANDARD_MEASURE = 500;
  
  private static class Fork extends MutualExclusion.SluiceJoined{
    
    private String user;

    public String getUser(){
      return user;
    }

    public void setUser(String user) throws Exception{
      if(user != null && this.user != null){
        throw new Exception("Thread " + user + "(" + Thread.currentThread() + ") is entering " + this + " owned by " + this.user + "!");
      }
      if(user == null && this.user == null){
        throw new Exception("Thread " + Thread.currentThread() + " is leaving " + this + ", but is not its owner!");
      }
      this.user = user;
    }
    
  }
    
  private static class Philosopher extends ControlledProcess{
    
    private SluiceCluster forksCluster;

    private Fork[] forks;
    
    private String name;
    
    private String status;
            
    private int eatTime;
    
    private long totalEatTime; 

    private Philosopher(Fork[] forks, String name, int sleepTime, int eatTime){
      super(sleepTime);
      this.forksCluster = new SluiceCluster(forks);
      this.forks = new Fork[forks.length];
      System.arraycopy(forks, 0, this.forks, 0, forks.length);
      this.totalEatTime = 0;
      this.eatTime = eatTime;
      this.status = Example.STATUS_SLEEPING;
      this.name = name;
    }

    public static Philosopher create(Fork[] forks, String name, int sleepTime, int eatTime){
      if(forks == null || forks.length == 0 || sleepTime < 1 || eatTime < 1){
        return null;
      }
      for(int i = 0; i < forks.length; i++){
        if(forks[i] == null){
          return null;
        }
      }
      return new Philosopher(forks, name, sleepTime, eatTime);
    }
    
    public void run(){
      int i = 0;
      // lifecycle
      while(this.isLiving()){
        // waiting
        this.status = Example.STATUS_WAITING;
        this.forksCluster.enter();    
        // eating
        this.status = Example.STATUS_EATING;
        while(i < this.forks.length){
          try{
            this.forks[i].setUser(this.name);
          }
          catch(Exception e){
            System.out.println(e.getMessage());
            System.exit(1);
          }
          i++;
        }
        i = 0;
        this.eat();
        while(i < this.forks.length){
          try{
            this.forks[i].setUser(null);
          }
          catch(Exception e){
            System.out.println(e.getMessage());
            System.exit(1);
          }
          i++;
        }
        i = 0;
        this.forksCluster.leave();
        // sleeping
        this.status = Example.STATUS_SLEEPING;
        this.sleep();
      }
    }
    
    private void eat(){
      long eatTime = (long)(this.eatTime * Math.random() + 1);
      Example.threadSleep( eatTime );
      this.totalEatTime = this.totalEatTime + eatTime;
    }
    
    private void sleep(){
      Example.threadSleep( (long)(this.getSleepTime() * Math.random() + 1) );
    }

    public String getStatus(){
      return status;
    }

    public long getTotalEatTime(){
      return totalEatTime;
    }

    public String toString(){
      return this.name;
    }

  }
    
  private static void threadSleep(long sleepTime){
    try{
      Thread.sleep(sleepTime);
    }
    catch(InterruptedException e){
      e.printStackTrace();
    }
  }
  
  private abstract static class ControlledProcess implements Runnable{
    
    private boolean living;
    
    private int sleepTime;
    
    protected ControlledProcess(int time){
      this.sleepTime = time;
      this.living = true;
    }

    public int getSleepTime(){
      return sleepTime;
    }

    public void setSleepTime(int sleepTime){
      if(sleepTime > 0){
        this.sleepTime = sleepTime;
      }
    }
    
    public boolean isLiving(){
      return this.living;
    }

    public void setLiving(boolean alive){
      this.living = alive;
    }
        
  }  
  
// MAIN ////////////////////////////////////////////////////////////////////////  
  
  public static void main(String[] args){
    int eatTime = 100;
    int sleepTime = 100;
    int countOfPhilosophers = 5;
    int outMeasure = 500;
    int inMeasure = 500;
    // prepaire Philosophers // prepaire OutputThread
    Philosopher[] philosophers = new Philosopher[countOfPhilosophers];    
    Fork firstFork = new Fork();
    Fork[] forks = new Fork[2];
    forks[0] = firstFork;
    int i = philosophers.length - 1;
    while(i > 0){
      forks[1] = new Fork();
      philosophers[i] = Philosopher.create(forks, Integer.toString(i), sleepTime, eatTime);
      forks[0] = forks[1];
      i--;
    }
    forks[1] = firstFork;
    philosophers[i] = Philosopher.create(forks, Integer.toString(i), sleepTime, eatTime);
    // start Philosophers
    i = philosophers.length - 1;
    while(i >= 0){
      (new Thread(philosophers[i])).start();
      i--;
    }
    // start OutputThread
    OutProcess.getInstance().initPhilosophers(philosophers);
    OutProcess.getInstance().setSleepTime(outMeasure);
    ( new Thread( OutProcess.getInstance() ) ).start();
    // prepaire InputThread
    ControlledProcess[] runnable = new ControlledProcess[countOfPhilosophers + 1];    
    System.arraycopy(philosophers, 0, runnable, 1, philosophers.length);
    runnable[0] = OutProcess.getInstance();
    // start InputThread
    InProcess.getInstance().setRunnable(runnable);
    InProcess.getInstance().setSleepTime(inMeasure);
    ( new Thread( InProcess.getInstance() ) ).start();
  }
    
// IN //////////////////////////////////////////////////////////////////////////  
  
  final static char COMMAND_QUIT = 'q';
  
  final static String HELP_QUIT = "To Quit type 'q' and enter";
  
  private static class InProcess extends ControlledProcess{

    private static InProcess instance;

    private ControlledProcess[] runnable;
        
    private InProcess(int sleepTime){
      super(sleepTime);
    }

    public static InProcess getInstance(){
      if(InProcess.instance == null){
        InProcess.instance = new InProcess(100);
      }
      return InProcess.instance;
    }
    
    public void run(){
      char in = ' ';
      while( !(in == COMMAND_QUIT) &&
             !(in == Character.toUpperCase(COMMAND_QUIT)) &&
             this.isLiving() ){
        Example.threadSleep(this.getSleepTime());
        in = Example.readSystemInFirstChar();
      }
      for(int i = 0; i < this.runnable.length; i++){
        this.runnable[i].setLiving(false);
      }
      this.setLiving(false);
    }

    public void setRunnable(ControlledProcess[] runnable){
      if(runnable != null && runnable.length > 0){
        this.runnable = runnable;
      }
    }
    
  }
  
  public static char readSystemInFirstChar(){
    char c = ' ';
    try{
      if(System.in.available() > 0){
        c = (char) ( System.in.read() );
        while(System.in.available() > 0){
          System.in.read();
        }
      }
    }
    catch(IOException e){
      e.printStackTrace();
    }
    return c;
  }
  
  public static String readSystemInLine(){
    String inStr = "";
    try{
      while(System.in.available() > 0){
        inStr = inStr + (char) ( System.in.read() );
      }
    }
    catch(IOException e){
      e.printStackTrace();
    }
    return inStr;
  }  
  
// OUT /////////////////////////////////////////////////////////////////////////  

  private static class OutProcess extends ControlledProcess{
    
    static String[] philosopherSleeping =
      new String[]{
           "---------------"
          ,"     ||||||    "
          ,"    (  _ _ )   "
          ,"     |    |    "
          ,"      \\_-/     "
          ,"               "
          ,"               "
          ,"               "
        };

    static String[] philosopherWaiting =
      new String[]{
           "---------------"
          ,"     ||||||    "
          ,"    (  . . )   "
          ,"     |    |    "
          ,"      \\_~/     "
          ,"               "
          ,"               "
          ,"               "
        };
    
    static String[] philosopherEating =
      new String[]{
           "---------------"
          ,"     ||||||    "
          ,"    (  . . )   "
          ,"|||  |    | |||"
          ,"\\ /   \\_o/  \\ /"
          ," |     ___   | "
          ," |  |\\/  :\\  | "
          ," |  |/\\___/  | "
        };

    private static OutProcess instance;
    
    private Philosopher[] philosophers;
    
    private OutProcess(int time){
      super(time);
    }
    
    public static OutProcess getInstance(){
      if(OutProcess.instance == null){
        OutProcess.instance = new OutProcess(100);
      }
      return OutProcess.instance;
    }   
    
    public void run(){
      int row = 0;
      int column = 0;
      if(this.philosophers != null){
        String[] status = new String[this.philosophers.length];
        int space = OutProcess.philosopherEating[0].length();
        String statusTotalEatTime;
        while(this.isLiving()){
          System.out.print("\n");
          // try to get a snapshot of philosophers status
          while(column < status.length){
            status[column] = this.philosophers[column].getStatus();
            column++;
          }
          column = 0;          
          // out graph
          while(row < OutProcess.philosopherEating.length){
            while(column < status.length){              
              if(status[column] == STATUS_EATING){
                System.out.print(OutProcess.philosopherEating[row]);
              }
              else{
                if(status[column] == STATUS_WAITING){
                  System.out.print(OutProcess.philosopherWaiting[row]);
                }
                else{
                  System.out.print(OutProcess.philosopherSleeping[row]);
                }
              }
              column++;
            }
            System.out.print("\n");
            column = 0;
            row++;
          }
          row = 0;
          // out status
          while(column < status.length){
            System.out.print(this.philosophers[column].toString());
            System.out.print(" is ");
            System.out.print(status[column]);
            while(row < space - this.philosophers[column].toString().length() -
                        4 - status[column].length()){
              System.out.print(" ");
              row++;
            }
            row = 0;
            column++;
          }
          column = 0;          
          System.out.print("\n");
          // try to get a snapshot of philosophers totalEatTime
          while(column < status.length){
            status[column] = Long.toString( this.philosophers[column].getTotalEatTime() );
            column++;
          }
          column = 0;
          // out totalEatTime
          while(column < status.length){
            statusTotalEatTime = this.philosophers[column].toString() + " eats";
            System.out.print(statusTotalEatTime);
            if(status[column].length() > space - statusTotalEatTime.length() - 2){
              System.out.print(">");
              while(row < space - statusTotalEatTime.length() - 2){
                System.out.print("9");
                row++;
              }
              System.out.print(" ");
              row = 0;
            }
            else{
              System.out.print(" ");
              System.out.print(status[column]);
              while(row < space - status[column].length() - statusTotalEatTime.length() - 1){
                System.out.print(" ");
                row++;
              }
              row = 0;
            }
            column++;
          }
          column = 0;          
          System.out.print("\n");
          System.out.print("__________________________\n");
          System.out.print(HELP_QUIT);
          Example.threadSleep(this.getSleepTime());
        }
      }
    }

    public void initPhilosophers(Philosopher[] philosophers){
      if(this.philosophers == null && philosophers != null && philosophers.length > 0){
        this.philosophers = philosophers;
      }
    }
    
  }

}