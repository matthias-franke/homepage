<?php
/**
 * The header for our theme
 *
 * This is the template that displays all of the <head> section and everything up until <div id="content">
 *
 * @link https://developer.wordpress.org/themes/basics/template-files/#template-partials
 *
 * @package WordPress
 * @subpackage Twenty_Seventeen
 * @since 1.0
 * @version 1.0
 */

?><!DOCTYPE html>
<html <?php language_attributes(); ?> class="no-js no-svg">
<head>
<meta charset="<?php bloginfo( 'charset' ); ?>">
<meta name="viewport" content="width=device-width, initial-scale=1">
<link rel="profile" href="http://gmpg.org/xfn/11">

<?php wp_head(); ?>
</head>

<body <?php body_class(); ?>>

	<a class="menu" id="menu" href="javascript:void(0);" onclick="toggleDisplay('nav');">&equiv;</a>

	
	<nav id="nav">
	<ul>
		
	<li><a href="index.html">&#8743;<span class="sub"> </span></a></li>

	<li><a href="toc.html#code">Code<span class="sub"> </span></a><ul>
		<li><a href="justus.html">Projekt Justus<span class="sub">  smart contracts</span></a></li>
		<li><a href="codePytemp.html">pytemp<span class="sub"> </span></a></li>
		<li><a href="codeCssMenu.html">CSS Webpage Menu<span class="sub"> </span></a></li>
	</ul></li>

	<li><a href="toc.html#text">Text<span class="sub"> </span></a><ul>
		<li><a href="toc.html#textFiktion">Fiktionales<span class="sub"> </span></a><ul>
			<li><a href="textFiktionVerlierer.html">Der Verlierer <span class="sub"> - Krimi - Fliesstext</span></a></li>
			<li><a href="textFiktionVerlierer/index.html">Der Verlierer <span class="sub"> - Krimi - interaktiv</span></a></li>
			<li><a href="textFiktionBrueller.html">Der Br&#252;ller <span class="sub"> - Ein Bericht</span></a></li>
		</ul></li>
		<li><a href="toc.html#textAcademic">Akademisches<span class="sub"> </span></a><ul>
			
			<li><a href="textAcademicInetLiteraturN.html">Literatur im Internet<span class="sub"> </span></a></li>
			<li><a href="wiah.html">Ein Versuch &#252;ber die Tendenz eines Witzes<span class="sub"> </span></a></li>
		</ul></li>		
		<li><a href="toc.html#textJournal">Journalistisches<span class="sub"> </span></a><ul>
			<li><a href="toc.html#textJournalBericht">Bericht<span class="sub"> </span></a><ul>
				<li><a href="toc.html#textJournalBerichtComputer">Computer<span class="sub"> </span></a><ul>
					<li><a href="jbahschachtner.html">Das virtuelle Geschlecht<span class="sub"> Interview mit Christina Schachtner</span></a></li>
					<li><a href="jbbhcomp.html">Unbekannte Wesen<span class="sub"> &#252;ber menschlichen Umgang mit Computern</span></a></li>
					<li><a href="jbchAlpar.html">WWW Wohin?<span class="sub"> Wie begr&#252;ndet ist das Internet-Fieber der Wirtschaftsstrategen?</span></a></li>
				</ul></li>
				<li><a href="toc.html#textJournalBerichtTechnik">Technik<span class="sub"> </span></a><ul>
					<li><a href="jbdhschalt.html">Die lineare Innovation<span class="sub"> Einige Entwicklungen bei Schaltwerken vor allem im MTB-Bereich</span></a></li>
					<li><a href="jbehhelm.html">Helm auf!<span class="sub"> Gesetzliche Helmpflicht f&#252;r Radfahrer</span></a></li>
					<li><a href="jbghdaemm.html">Die regenerativen Alternativen<span class="sub"> Wie nat&#252;rlich sind die Naturd&#228;mmstoffe?</span></a></li>
				</ul></li>				
				<li><a href="toc.html#textJournalBerichtGesundheit">Gesundheit<span class="sub"> </span></a><ul>
					<li><a href="jbhhfuss.html">Von Kindesbeinen an getreten: Die F&#252;&#223;e<span class="sub"> </span></a></li>
					<li><a href="jbihvitamin.html">Sch&#228;den durch Vitamin A?<span class="sub"> </span></a></li>
				</ul></li>				
				<li><a href="toc.html#textJournalBerichtWirtschaft">Wirtschaft<span class="sub"> </span></a><ul>
					<li><a href="jbjhecom.html">Gesch&#228;fte gehen ins Netz<span class="sub"> Die neue Studie zu den Schwierigkeiten der Unternehmer mit Electronic Commerce</span></a></li>
					<li><a href="jbkhboerse.html">B&#246;rse zweiter Klasse<span class="sub"> Bauaktien leiden an der Wiener B&#246;rse</span></a></li>
					<li><a href="jbrhimmobil.html">Immobilien<span class="sub"> </span></a></li>
					<li><a href="jbshmarkt.html">Markt<span class="sub"> </span></a></li>
					<li><a href="jbthkooper.html">Baumit-Kooperation<span class="sub"> </span></a></li>
				</ul></li>	
				<li><a href="toc.html#textJournalBerichtRegionales">Regionales<span class="sub"> </span></a><ul>
					<li><a href="jblhgolf.html">Generation Golf<span class="sub"> Studenten &#252;ben sich in der Kulturtechnik Golf</span></a></li>
					<li><a href="jbmhJacob.html">Erinnerungsst&#252;cke<span class="sub"> Eine Ausstellung zeigt Familiengeschichte</span></a></li>
					<li><a href="jbnhfundland.html">Natur-nah<span class="sub"> Der Reiseveranstalter "NeuFundLand" bietet Naturerlebnisse im Marburger Umland</span></a></li>
					<li><a href="jbohloet.html">L&#246;tkolben<span class="sub"> Der Motoradclub Wohratal</span></a></li>
					<li><a href="jbphkonz.html">Lehrer ohne Pauken<span class="sub"> musizierende P&#228;dagogen</span></a></li>
					<li><a href="jbqhgesang.html">Gesangverein<span class="sub"> Jubil&#228;umsfeier in Kirchhain</span></a></li>
				</ul></li>				
			</ul></li>
			<li><a href="toc.html#textJournalKritik">Kritik<span class="sub"> </span></a><ul>
				<li><a href="jkrhbauman.html">Das Spiel ist wie Krieg<span class="sub"> Zygmunt Bauman erkundet die postmoderne Befindlichkeit und die Befindlichkeit der Postmoderne</span></a></li>
				<li><a href="jkrhbertz.html">Das Fahrrad im Dienste der Volksgesundheit<span class="sub"> Ein Fahrradbuch offenbart Denken seiner Entstehungszeit</span></a></li>
				<li><a href="jkrhbrockhaus.html">Salon Brockhaus<span class="sub"> Der "Gro&#223;e Brockhaus" multimedial</span></a></li>
				<li><a href="jkrhcasanova.html">Der Westentaschen-Casanova<span class="sub"> Charles Lewinsky serviert Weisheiten des Giacomo Girolamo Casanova</span></a></li>
			</ul></li>			
		</ul></li>			
	</ul></li>
	
	<li><a href="foto.html">Foto<span class="sub"> </span></a></li>
	
	<li><a href="satire.html">Satire<span class="sub"> </span></a></li>
	
	<li><a href="toc.html#workbench">Basteln<span class="sub"> </span></a><ul>
		<li><a href="toc.html#workbench">Liegerad<span class="sub"> </span></a><ul>
					
			<li><a href="lieraBeschreibung.html">Beschreibung<span class="sub"> </span></a></li>
			<li><a href="lieraTheorie.html">Theorie<span class="sub"> </span></a></li>
			<li><a href="lieraAbstract.html">Abstract<span class="sub"> </span></a></li>
		</ul></li>	
	</ul></li>

	

	</ul>
</nav>




<div id="page" class="site">
	

	<div class="site-content-contain">
		<div id="content" class="site-content">
